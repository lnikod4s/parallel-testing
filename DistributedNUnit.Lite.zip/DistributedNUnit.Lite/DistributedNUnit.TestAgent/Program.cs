﻿using System;
using DistributedNUnit.RabbitMq.Client.Incoming;
using DistributedNUnit.RabbitMq.Client.Outgoing;
using Microsoft.Extensions.CommandLineUtils;

namespace DistributedNUnit.TestAgent
{
	class Program
    {
        static void Main(params string[] args)
        {
			try
			{
				CommandLineApplication commandLineApplication = new CommandLineApplication(throwOnUnexpectedArg: true);

				CommandOption agentTagName = commandLineApplication.Option(
					"-$|-a |--agentTagName <UnitTestsAgent1>",
					"The tag for the test agent that is starting.",
					CommandOptionType.SingleValue);

				commandLineApplication.HelpOption("-? | -h | --help");

				commandLineApplication.OnExecute(() =>
				{
					var consumer = new Consumer();
					consumer.ProcessTestRunMessages(agentTagName.Value());
					return 0;
				});
				commandLineApplication.Execute(args);
			}
			catch (Exception ex)
			{
				new Producer().SendErrorMessage(ex.ToString());
				Console.WriteLine(ex.ToString());
			}			
        }
    }
}