﻿using System;

namespace DistributedNUnit.Interfaces
{
    public interface IOutputFilesService
    {
        void CopyOutputFilesToSharedLocation(Guid testRunId, string sharedOutputFilesLocation, string originalOutputFilesLocation);

        void CopyResultsOutputFilesToResultsOutputLocation(string workingDirectory, string resultsOutputLocation, params string[] excludeDirs);

        string CreateLocalTestListFile(string testList);
    }
}