﻿using System.Collections.Generic;

namespace DistributedNUnit.Interfaces
{
    public interface ITestSuiteFilterService
    {
        List<TestSuite> FilterTestSuitesByTestCaseCategoriesAnyMatch(List<TestSuite> testSuites, params string[] testCaseCategoryNames);

		List<TestSuite> FilterTestSuitesByTestCaseCategoriesAllMatch(List<TestSuite> testSuites, params string[] testCaseCategoryNames);
	}
}