﻿namespace DistributedNUnit.Interfaces
{
    public interface IPathProvider
    {
        string GetFileName(string file);

        string Combine(string paths1, string path2);

        string Combine(string paths1, string path2, string path3);

        string GetTempFileName();

        string GetTempFolderPath();

		string GetDirectoryName(string fullPath);

		string GetExecutingAssemblyDirectory();
    }
}