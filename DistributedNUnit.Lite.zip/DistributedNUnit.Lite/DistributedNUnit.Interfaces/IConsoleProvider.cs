﻿namespace DistributedNUnit.Interfaces
{
    public interface IConsoleProvider
    {
        void WriteLine(string format, params string[] arguments);

        void WriteLine(string message);

        void Write(string format, params string[] arguments);

        void Write(string message);

        string ReadLine();
    }
}