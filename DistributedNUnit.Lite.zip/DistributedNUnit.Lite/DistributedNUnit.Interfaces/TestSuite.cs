﻿using System.Collections.Generic;

namespace DistributedNUnit.Interfaces
{
	public class TestSuite
	{
		public string FullName { get; set; }

		public List<string> Categories { get; set; }

		public List<TestCase> TestCases { get; set; }

		public decimal ExecutionTime { get; set; }
	}
}