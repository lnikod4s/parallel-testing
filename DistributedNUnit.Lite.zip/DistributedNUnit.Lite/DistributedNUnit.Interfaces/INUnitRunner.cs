﻿using System;
using System.Threading;

namespace DistributedNUnit.Interfaces
{
	public interface INUnitRunner
    {
        string ExecuteNUnitTests(string testListFilePath, string workingDir, Guid testRunId, string testsAssembly, Action<string> dispatchConsoleOutput, CancellationToken cancellationTokenout, out bool testResultsStatus);
    }
}