﻿using System;
using System.Collections.Generic;
using System.Reflection;

namespace DistributedNUnit.Interfaces
{
	public interface IReflectionProvider
	{
		Assembly GetAssemblyFromFile(string fullFilePath);

		Type[] GetTypes(Assembly assembly);

		MethodInfo[] GetMethods(Type type);

		IEnumerable<Attribute> GetCustomAttributes(Type type);

		IEnumerable<Attribute> GetCustomAttributes(MethodInfo method);

		string GetTypeFullName(Type type);

		string GetMethodReflectedTypeFullName(MethodInfo method);

		string GetMethodName(MethodInfo method);
	}
}