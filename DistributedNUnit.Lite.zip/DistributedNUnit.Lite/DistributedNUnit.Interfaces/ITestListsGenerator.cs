﻿using System.Collections.Generic;
using System.Runtime.CompilerServices;

namespace DistributedNUnit.Interfaces
{
    public interface ITestListsGenerator
    {
        List<(string Tests, decimal Time)> Generate(int testAgentsCount, string testAssemblyPath, string testCategories, Dictionary<string, decimal> testExecutionTimes);
    }
}