﻿namespace DistributedNUnit.Interfaces
{
    public interface IFileProvider
    {
        void Copy(string sourceFileName, string destFileName, bool overwrite);

        void WriteAllText(string path, string contents);

        string ReadAllText(string path);

        void Delete(string path);

        bool IsWithExtension(string filePath, string extension);
    }
}