﻿using System.Collections.Generic;

namespace DistributedNUnit.Interfaces
{
    public interface ITestSuiteProvider
    {
        List<TestSuite> ExtractAllTestSuitesFromAssembly(string assemblyPath);
    }
}