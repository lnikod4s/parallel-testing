﻿using System;
using System.Collections.Generic;

namespace DistributedNUnit.Interfaces
{
    public interface ITestRunProvider
    {
		ITestRun CreateNewTestRun(Guid testRunId, string testList, string testAssemblyLocation, string testAssemblyName, string testAgentTag, string testLogOutputLocation, int agentTimeout, IReadOnlyList<byte> testsPackage, decimal estimatedTime, params string[] excludeOutputFolders);
    }
}