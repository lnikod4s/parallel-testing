﻿using System.Collections.Generic;

namespace DistributedNUnit.Interfaces
{
    public interface IZipTestPackageProvider
    {
        IReadOnlyList<byte> Create(string folderLocation);
    }
}