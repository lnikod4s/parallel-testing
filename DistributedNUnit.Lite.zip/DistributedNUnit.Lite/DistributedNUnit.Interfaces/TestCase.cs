﻿using System.Collections.Generic;

namespace DistributedNUnit.Interfaces
{
	public class TestCase
	{
		public string FullName { get; set; }

		public List<string> Categories { get; set; }

		public decimal ExecutionTime { get; set; }
	}
}