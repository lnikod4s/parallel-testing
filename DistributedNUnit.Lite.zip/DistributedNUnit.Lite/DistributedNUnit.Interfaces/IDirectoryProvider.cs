﻿namespace DistributedNUnit.Interfaces
{
    public interface IDirectoryProvider
    {
        bool DoesDirectoryExists(string path);

        string[] GetFiles(string path);

        void CreateDirectory(string path);
    }
}