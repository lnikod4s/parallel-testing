﻿using System;
using System.Threading;

namespace DistributedNUnit.Interfaces
{
	public interface IProcessProvider
    {
        int StartProcess(
            string fileName,
            string workingDir,
            string arguments,
			CancellationToken cancellationToken,
			Action<string> standardOutputCallback = null,
            Action<string> errorOutputCallback = null);

		void StartParentlessProcess(string fileName, string arguments);

		void KillProcess(int processId);
	}
}