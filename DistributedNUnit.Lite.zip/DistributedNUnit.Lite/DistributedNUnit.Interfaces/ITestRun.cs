﻿using System;

namespace DistributedNUnit.Interfaces
{
    public interface ITestRun
	{
		Guid TestRunId { get; set; }

		string TestList { get; set; }

		string TestAssemblyLocation { get; set; }

		string TestAssemblyName { get; set; }

		string TestLogOutputLocation { get; set; }

		string TestAgentTag { get; set; }

        int Timeout { get; set; }

        string TestsPackage { get; set; }

		decimal EstimatedExecutionTime { get; set; }

		Guid InstanceId { get; set; }

		string[] ЕxcludeOutputFolders { get; set; }
	}
}