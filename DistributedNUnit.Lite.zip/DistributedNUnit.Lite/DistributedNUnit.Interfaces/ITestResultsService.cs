﻿namespace DistributedNUnit.Interfaces
{
	public interface ITestResultsService
    {
        void SaveTestResults(string testResults, string testResultsFolder, int totalResultsCount);
    }
}