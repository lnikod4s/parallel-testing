﻿using System.Collections.Generic;
using System.Linq;
using DistributedNUnit.Interfaces;

namespace DistributedNUnit.Services
{
	public class TestSuiteFilterService : ITestSuiteFilterService
	{
		public List<TestSuite> FilterTestSuitesByTestCaseCategoriesAnyMatch(List<TestSuite> testSuites, params string[] testCaseCategoryNames)
		{
			var testSuitesToBeRemoved = new List<TestSuite>();
			var filteredTestSuites = testSuites.GetRange(0, testSuites.Count);

			foreach (TestSuite currentTestSuite in filteredTestSuites)
			{
				var testCasesToBeRemoved = new List<TestCase>();

				for (int currentTestCase = 0; currentTestCase < currentTestSuite.TestCases.Count; currentTestCase++)
				{
					if (this.IsTestCaseInCategory(currentTestSuite.TestCases[currentTestCase], testCaseCategoryNames))
					{
						continue;
					}
					else
					{
						testCasesToBeRemoved.Add(currentTestSuite.TestCases[currentTestCase]);
					}
				}

				foreach (TestCase testCaseToBeRemoved in testCasesToBeRemoved)
				{
					currentTestSuite.TestCases.Remove(testCaseToBeRemoved);
				}

				if (currentTestSuite.TestCases.Count == 0)
				{
					testSuitesToBeRemoved.Add(currentTestSuite);
				}
			}

			foreach (TestSuite testSuiteToBeRemoved in testSuitesToBeRemoved)
			{
				filteredTestSuites.Remove(testSuiteToBeRemoved);
			}

			return filteredTestSuites;
		}

		public List<TestSuite> FilterTestSuitesByTestCaseCategoriesAllMatch(List<TestSuite> testSuites, params string[] testCaseCategoryNames)
		{
			var testSuitesToBeRemoved = new List<TestSuite>();
			var filteredTestSuites = testSuites.GetRange(0, testSuites.Count);

			foreach (TestSuite currentTestSuite in filteredTestSuites)
			{
				var testCasesToBeRemoved = new List<TestCase>();

				for (int currentTestCase = 0; currentTestCase < currentTestSuite.TestCases.Count; currentTestCase++)
				{
					if (this.IsTestCaseInAllCategories(currentTestSuite.TestCases[currentTestCase], testCaseCategoryNames))
					{
						continue;
					}
					else
					{
						testCasesToBeRemoved.Add(currentTestSuite.TestCases[currentTestCase]);
					}
				}

				foreach (TestCase testCaseToBeRemoved in testCasesToBeRemoved)
				{
					currentTestSuite.TestCases.Remove(testCaseToBeRemoved);
				}

				if (currentTestSuite.TestCases.Count == 0)
				{
					testSuitesToBeRemoved.Add(currentTestSuite);
				}
			}

			foreach (TestSuite testSuiteToBeRemoved in testSuitesToBeRemoved)
			{
				filteredTestSuites.Remove(testSuiteToBeRemoved);
			}

			return filteredTestSuites;
		}

		private bool IsTestCaseInCategory(TestCase testCase, string[] categoryNames)
		{
			bool result = false;

			if (categoryNames.Length > 0)
			{
				foreach (string categoryName in categoryNames)
				{
					if (testCase.Categories.Any(x => x.Equals(categoryName)))
					{
						result = true;
					}
				}
			}
			else
			{
				result = true;
			}

			return result;
		}

		private bool IsTestCaseInAllCategories(TestCase testCase, string[] categoryNames)
		{
			bool result = false;

			if (testCase.Categories.Count > 0)
			{
				if (categoryNames.All(x => testCase.Categories.Contains(x)))
				{
					result = true;
				}
				else
				{
					result = false;
				}
			}
			else
			{
				result = true;
			}

			return result;
		}
	}
}