﻿using System;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using DistributedNUnit.Infrastructure;
using DistributedNUnit.Interfaces;
using DistributedNUnit.Model;
using DistributedNUnit.RabbitMq.Client.Outgoing;

namespace DistributedNUnit.Services
{
	public class TestAgentExecutionService
    {
		private readonly INUnitRunner nunitRunner;
		private readonly IOutputFilesService outputFilesService;
		private readonly IPathProvider pathProvider;
		private readonly IDirectoryProvider directoryProvider;
		private readonly IConsoleProvider consoleProvider;
		private Guid currentTestRunId;
		private Producer producer;

		public TestAgentExecutionService(
			INUnitRunner nunitRunner,
			IOutputFilesService outputFilesService,
			IPathProvider pathProvider,
			IDirectoryProvider directoryProvider,
			IConsoleProvider consoleProvider)
		{
			this.nunitRunner = nunitRunner;
			this.outputFilesService = outputFilesService;
			this.pathProvider = pathProvider;
			this.directoryProvider = directoryProvider;
			this.consoleProvider = consoleProvider;
		}

		public void Execute(TestRun testRun, CancellationToken cancellationToken)
        {
            if (cancellationToken.IsCancellationRequested)
			{
				return;
			}

			this.producer = new Producer();
			this.currentTestRunId = testRun.TestRunId;
			// Here run the tests and hook the producer to hte console output.

			string testListPath = this.outputFilesService.CreateLocalTestListFile(testRun.TestList);
			string testRunTestsAssemblyPath = this.GetTestRunTestsAssemblyPath(testRun);
			string tempDirectory = this.pathProvider.GetTempFolderPath();
			Console.WriteLine("[*] Current temp folder: " + tempDirectory);
			string workingDirectory = this.pathProvider.Combine(tempDirectory, Guid.NewGuid().ToString());
			this.directoryProvider.CreateDirectory(workingDirectory);
			string resultStatus = "Success";
			string testsResults = string.Empty;
			bool testResultsStatus = false;
			Stopwatch stopwatch = new Stopwatch();
			try
			{
				// This sends started message on the results channel to notify the controller that the execution has started and to turn on the timeout timer.
				this.StartTestRunControllerTimeout(testRun.TestRunId, testRun.TestAgentTag);

				// Start the tests execution and receive the results.
				stopwatch.Start();
				testsResults = this.nunitRunner.ExecuteNUnitTests(testListPath, workingDirectory, testRun.TestRunId, testRunTestsAssemblyPath, this.LogStadardOutput, cancellationToken, out testResultsStatus);
				stopwatch.Stop();
			}
			catch (System.OperationCanceledException ex)
			{
				resultStatus = $"Fail : The cancelation was requested by the token. Full exception: {ex}";
			}
			catch (Exception ex)
			{
				resultStatus = $"Fail : Full exception: {ex}";
			}

			try
			{
				this.outputFilesService.CopyResultsOutputFilesToResultsOutputLocation(workingDirectory, testRun.TestLogOutputLocation, testRun.ЕxcludeOutputFolders);
			}
			catch (Exception ex)
			{
				this.producer.SendErrorMessage(ex.ToString());
;			}

			// Here notify the controller when the test results are ready.
			this.CompleteTestAgentRun(testRun.TestRunId, testsResults, resultStatus, testRun.TestAgentTag, testResultsStatus, testRun.InstanceId, stopwatch.Elapsed.TotalSeconds);
		}

		private string GetTestRunTestsAssemblyPath(TestRun testRun)
		{
            if (testRun.TestAssemblyLocation != "local")
            {
                string pathToTestsAssembly = this.pathProvider.Combine(testRun.TestAssemblyLocation, testRun.TestRunId.ToString(), testRun.TestAssemblyName);

                return pathToTestsAssembly;
            }
            else
            {
                var tempLocation = this.pathProvider.GetTempFolderPath();
                string zipPath = this.pathProvider.Combine(tempLocation, Guid.NewGuid().ToString() + ".zip");
                File.WriteAllBytes(zipPath, Convert.FromBase64String(testRun.TestsPackage));
                string extractLocation = this.pathProvider.Combine(tempLocation, testRun.TestRunId.ToString());

                ZipFile.ExtractToDirectory(zipPath, extractLocation);

                return this.pathProvider.Combine(extractLocation, testRun.TestAssemblyName);
            }
		}

		private void CompleteTestAgentRun(Guid testRunId, string testResults, string status, string tagName, bool isTestResultSuccess, Guid resultId, double timeTaken)
		{
			var testResult = new TestRunResult()
			{
				TestRunId = testRunId,
				Status = status,
				TestResults = testResults,
				IsTestsResultSuccess = isTestResultSuccess,
				ResultId = resultId,
				TimeTaken = timeTaken
			};

			this.producer.SendTestRunResultMessage(testResult, tagName);
		}

		private void LogStadardOutput(string message)
		{
			try
			{
				if (message != null && !message.Contains("Test:") && message.Contains("=>"))
				{
					this.producer.SendTestRunConsoleOutputMessage(message, this.currentTestRunId);
				}
				this.consoleProvider.WriteLine(message);
			}
			catch (Exception)
			{
				// We don't care as much for the console output;	
			}
		}

		private void StartTestRunControllerTimeout(Guid testRunId, string tagName)
		{
			var testResult = new TestRunResult()
			{
				TestRunId = testRunId,
				Status = "Started"
			};

			this.producer.SendTestRunResultMessage(testResult, tagName);
		}
	}
}