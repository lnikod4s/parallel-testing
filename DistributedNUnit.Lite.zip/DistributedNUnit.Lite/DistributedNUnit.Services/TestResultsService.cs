﻿using System;
using DistributedNUnit.Infrastructure;
using DistributedNUnit.Interfaces;
using DistributedNUnit.RabbitMq.Client.Outgoing;

namespace DistributedNUnit.Services
{
	public class TestResultsService : ITestResultsService
	{
		private readonly IFileProvider fileProvider;
		private readonly IDirectoryProvider directoryProvider;
		private readonly IPathProvider pathProvider;

		public TestResultsService(
			IFileProvider fileProvider,
			IDirectoryProvider directoryProvider,
			IPathProvider pathProvider)
		{
			this.fileProvider = fileProvider;
			this.directoryProvider = directoryProvider;
			this.pathProvider = pathProvider;
		}

		public void SaveTestResults(string testResults, string testResultsFolder, int totalResultsCount)
		{
			this.EnsureResultsDirectoryExists(testResultsFolder);
			this.WriteTestAgentRunsResultsToFilesInResultsDirectory(testResultsFolder, testResults);
			if (totalResultsCount > 1)
			{
				this.UpdateTestExecutionTimes(testResults);
				this.UpdateClassExecutionTimes(testResults);
			}
		}

		private void WriteTestAgentRunsResultsToFilesInResultsDirectory(string testResultsFolder, string testResults)
		{
			if (string.IsNullOrEmpty(testResultsFolder))
			{
				testResultsFolder = this.pathProvider.GetExecutingAssemblyDirectory();
			}

			if (!string.IsNullOrEmpty(testResults))
			{
				string newFileName = this.pathProvider.Combine(testResultsFolder, string.Format("{0}.xml", Guid.NewGuid().ToString()));
				this.fileProvider.WriteAllText(newFileName, testResults);
			}
		}

		private void EnsureResultsDirectoryExists(string testResultsFolder)
		{
			if (!string.IsNullOrEmpty(testResultsFolder) && !this.directoryProvider.DoesDirectoryExists(testResultsFolder))
			{
				this.directoryProvider.CreateDirectory(testResultsFolder);
			}
		}

		private void UpdateTestExecutionTimes(string currentResults)
		{
			var testsTimes = new NunitTestResultsProvider().GetTestMethodsExecutionTime(currentResults);

			new RedisProvider().SaveTestsTimes(testsTimes);
		}

		private void UpdateClassExecutionTimes(string currentResults)
		{
			var classesTimes = new NunitTestResultsProvider().GetTestClassesExecutionTime(currentResults);

			new RedisProvider().SaveTestsTimes(classesTimes);
		}
	}
}