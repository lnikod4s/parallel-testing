﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DistributedNUnit.Interfaces;
using DistributedNUnit.Logger;

namespace DistributedNUnit.Services
{
    public class TestListsGenerator : ITestListsGenerator
    {
        private const string SingleMachineTestSuiteCategory = "ExecuteTestsOnSingleMachine";
        private readonly ITestSuiteProvider testSuiteProvider;
        private readonly ITestSuiteFilterService testSuiteFilterService;

        public TestListsGenerator(ITestSuiteProvider testSuiteProvider, ITestSuiteFilterService testSuiteFilterService)
        {
            this.testSuiteProvider = testSuiteProvider;
            this.testSuiteFilterService = testSuiteFilterService;
        }

        public List<(string Tests, decimal Time)> Generate(int testAgentsCount, string testAssemblyPath, string testCategories, Dictionary<string, decimal> testExecutionTimes)
        {
            if (testAgentsCount <= 0)
            {
                throw new ArgumentException("Test Agents Count Must be Greater Than 0.");
            }

            if (testCategories == null)
            {
                testCategories = string.Empty;
            }

            var allTestSuites = this.testSuiteProvider.ExtractAllTestSuitesFromAssembly(testAssemblyPath);
            this.LogTotalTestCasesCount(allTestSuites, "total");

            string[] allTestCategories = new string[0];

            var filteredTestSuites = new List<TestSuite>();

            if (testCategories != string.Empty && testCategories.Contains("+"))
            {
                allTestCategories = testCategories.Split('+');
                filteredTestSuites = this.testSuiteFilterService.FilterTestSuitesByTestCaseCategoriesAllMatch(allTestSuites, allTestCategories);
            }
            else if (testCategories != string.Empty)
            {
                allTestCategories = testCategories.Split('_');
                filteredTestSuites = this.testSuiteFilterService.FilterTestSuitesByTestCaseCategoriesAnyMatch(allTestSuites, allTestCategories);
            }
            else
            {
                filteredTestSuites = allTestSuites;
            }

            this.LogTotalTestCasesCount(filteredTestSuites, "filtered");

            var distributedTestLists = this.GenerateTestListsFormTestSuites(testAgentsCount, filteredTestSuites, testExecutionTimes);

            return distributedTestLists;
        }

        private List<(string Tests, decimal Time)> GenerateTestListsFormTestSuites(int testListsCount, List<TestSuite> testSuites, Dictionary<string, decimal> testExecutionTimes)
        {
            var perTestCaseTestSuites = testSuites.Where(x => !x.Categories.Contains(SingleMachineTestSuiteCategory)).ToList();
            var perTestSuiteTestSuites = testSuites.Where(x => x.Categories.Contains(SingleMachineTestSuiteCategory)).ToList();

            var testListsPerTestCase = this.GetTestListsFromTestSuitesPerTestCase(perTestCaseTestSuites, testListsCount, testExecutionTimes);
            var testListsPerTestSuite = this.GetTestListsFromTestSuitesPerTestSuite(perTestSuiteTestSuites, testListsCount, testExecutionTimes);

            var result = new List<(string Tests, decimal Time)>();

            for (int i = 0; i < testListsCount; i++)
            {
                result.Add((Tests: this.MergeTestLists(testListsPerTestCase.ElementAt(i).Tests, testListsPerTestSuite.ElementAt(i).Tests), testListsPerTestCase.ElementAt(i).Time + testListsPerTestSuite.ElementAt(i).Time));
            }

            return result;
        }

        private List<string> GetAllTestCasesFromTestSuites(List<TestSuite> testSuites)
        {
            var result = new List<string>();

            foreach (TestSuite testSuite in testSuites)
            {
                result.AddRange(testSuite.TestCases.Select(x => x.FullName));
            }

            return result;
        }

        private List<(string Tests, decimal Time)> GetTestListsFromTestSuitesPerTestCase(List<TestSuite> testSuites, int testListsCount, Dictionary<string, decimal> testCaseExecutionTimes)
        {
            List<string> allTestCases = this.GetAllTestCasesFromTestSuites(testSuites);
            var timedTestCases = this.AssembleTimedTestCases(allTestCases, testCaseExecutionTimes);
            var distributedTestCases = this.DistributeTestCasesBasedOnTime(testListsCount, timedTestCases);

            var result = distributedTestCases.Select(x => (Tests: string.Join(Environment.NewLine, x.Select(y => y.FullName)) + Environment.NewLine, Time: x.Sum(y => y.ExecutionTime)));

            return result.ToList();
        }

        private List<(string Tests, decimal Time)> GetTestListsFromTestSuitesPerTestSuite(List<TestSuite> testSuites, int testListsCount, Dictionary<string, decimal> testSuiteExecutionTimes)
        {
            var timedTestSuites = this.AssembleTimedTestSuites(testSuites, testSuiteExecutionTimes);
            var distributedTestCases = this.DistributeTestSuitesBasedOnTime(testListsCount, timedTestSuites);

            var result = distributedTestCases.Select(x => (Tests: string.Join(Environment.NewLine, x.Item1.Select(y => y.FullName)) + Environment.NewLine, Time: x.Item2));

            return result.ToList();
        }

        private string AddTestCaseToTestList(string testCase, string testList)
        {
            var sb = new StringBuilder();
            sb.Append(testList);
            sb.Append(testCase);
            sb.Append(Environment.NewLine);

            return sb.ToString();
        }

        private string MergeTestLists(params string[] testLists)
        {
            var sb = new StringBuilder();
            foreach (string testList in testLists)
            {
                sb.Append(testList);
            }

            return sb.ToString();
        }

        private void LogTotalTestCasesCount(List<TestSuite> testSuites, string when)
        {
            int totalCasesCount = 0;

            foreach (var testSuite in testSuites)
            {
                totalCasesCount += testSuite.TestCases.Count;
            }

            Console.WriteLine($" [*] Found {when} test cases count: {totalCasesCount}");
        }

        private List<TestCase> AssembleTimedTestCases(List<string> testCasesNames, Dictionary<string, decimal> testCaseExecutionTimes)
        {
            List<TestCase> testCases = new List<TestCase>();

            foreach (var testCaseName in testCasesNames)
            {
                TestCase testCase = new TestCase();
                testCase.FullName = testCaseName;

                if (testCaseExecutionTimes.ContainsKey(testCaseName))
                {
                    testCase.ExecutionTime = testCaseExecutionTimes[testCaseName];
                }
                else
                {
                    testCase.ExecutionTime = 3;
                }

                testCases.Add(testCase);
            }

            return testCases;
        }

        private List<TestSuite> AssembleTimedTestSuites(List<TestSuite> testSuites, Dictionary<string, decimal> testSuiteExecutionTimes)
        {
            for (int i = 0; i < testSuites.Count; i++)
            {
                if (testSuiteExecutionTimes.ContainsKey(testSuites[i].FullName))
                {
                    testSuites[i].ExecutionTime = testSuiteExecutionTimes[testSuites[i].FullName];
                }
                else
                {
                    testSuites[i].ExecutionTime = 30;
                }
            }

            return testSuites;
        }

        private List<List<TestCase>> DistributeTestCasesBasedOnTime(int listsCount, List<TestCase> allTestCases)
        {
            allTestCases.Sort(delegate (TestCase x, TestCase y) { return -1 * x.ExecutionTime.CompareTo(y.ExecutionTime); });
            List<List<TestCase>> result = new List<List<TestCase>>();
            var avarageListTime = allTestCases.Sum(x => x.ExecutionTime) / listsCount;
            ConsoleLogger.Log($"Avarage by test time = {avarageListTime}");

            for (int i = 0; i < listsCount; i++)
            {
                result.Add(new List<TestCase>());
            }

            while (allTestCases.Count > 0)
            {
                for (int i = 0; i < listsCount; i++)
                {
                    if (allTestCases.Count > 0 && result[i].Sum(x => x.ExecutionTime) + allTestCases.First().ExecutionTime < avarageListTime + ((5 * avarageListTime) / 100))
                    {
                        var currentTestCase = allTestCases.First();
                        result[i].Add(currentTestCase);
                        allTestCases.Remove(currentTestCase);
                    }
                    else if (allTestCases.Count > 0)
                    {
                        result.Sort(delegate (List<TestCase> x, List<TestCase> y) { return x.Sum(t => t.ExecutionTime).CompareTo(y.Sum(t => t.ExecutionTime)); });
                        var currentTestCase = allTestCases.First();
                        ConsoleLogger.Log($"*Added overflowed test to current total: {result.First().Sum(x => x.ExecutionTime)} - test: {currentTestCase.ExecutionTime}");
                        result.First().Add(currentTestCase);
                        allTestCases.Remove(currentTestCase);
                    }
                }

                if (result.All(x => x.Sum(y => y.ExecutionTime) >= avarageListTime) && allTestCases.Count > 0)
                {
                    ConsoleLogger.Log("*Final additions...");
                    result.Sort(delegate (List<TestCase> x, List<TestCase> y) { return x.Sum(t => t.ExecutionTime).CompareTo(y.Sum(t => t.ExecutionTime)); });
                    int listIndex = 0;
                    for (int i = 0; i < allTestCases.Count; i++)
                    {
                        result[listIndex].Add(allTestCases[i]);
                        listIndex++;
                        if (listIndex == listsCount)
                        {
                            listIndex = 0;
                        }
                    }
                    break;
                }
            }

            result.Sort(delegate (List<TestCase> x, List<TestCase> y) { return x.Sum(t => t.ExecutionTime).CompareTo(y.Sum(t => t.ExecutionTime)); });
            for (int i = 0; i < listsCount; i++)
            {
                ConsoleLogger.Log("Final agent total time by test = " + result[i].Sum(x => x.ExecutionTime));
            }

            return result;
        }

        private List<(List<TestCase>, decimal)> DistributeTestSuitesBasedOnTime(int listsCount, List<TestSuite> allTestSuites)
        {
            List<(List<TestCase>, decimal)> result = new List<(List<TestCase>, decimal)>();
            List<List<TestSuite>> testSuitesLists = new List<List<TestSuite>>();

            var avarageListTime = allTestSuites.Sum(x => x.ExecutionTime) / listsCount;
            ConsoleLogger.Log($"Avarage by class time = {avarageListTime}");

            for (int i = 0; i < listsCount; i++)
            {
                testSuitesLists.Add(new List<TestSuite>());
            }

            while (allTestSuites.Count > 0)
            {
                for (int i = 0; i < listsCount; i++)
                {
                    if (allTestSuites.Count > 0 && testSuitesLists[i].Sum(x => x.ExecutionTime) + allTestSuites.First().ExecutionTime < avarageListTime)
                    {
                        var currentTestSuite = allTestSuites.First();
                        testSuitesLists[i].Add(currentTestSuite);
                        allTestSuites.Remove(currentTestSuite);
                    }
                    else if (allTestSuites.Count > 0)
                    {
                        testSuitesLists.Sort(delegate (List<TestSuite> x, List<TestSuite> y) { return x.Sum(t => t.ExecutionTime).CompareTo(y.Sum(t => t.ExecutionTime)); });
                        var currentTestSuite = allTestSuites.First();
                        testSuitesLists.First().Add(currentTestSuite);
                        allTestSuites.Remove(currentTestSuite);
                    }
                }

                if (testSuitesLists.All(x => x.Sum(y => y.ExecutionTime) >= avarageListTime) && allTestSuites.Count > 0)
                {
                    testSuitesLists.Sort(delegate (List<TestSuite> x, List<TestSuite> y) { return x.Sum(t => t.ExecutionTime).CompareTo(y.Sum(t => t.ExecutionTime)); });
                    int listIndex = 0;
                    for (int i = 0; i < allTestSuites.Count; i++)
                    {
                        testSuitesLists[listIndex].Add(allTestSuites[i]);
                        listIndex++;
                        if (listIndex == listsCount)
                        {
                            listIndex = 0;
                        }
                    }
                    break;
                }
            }

            testSuitesLists.Sort(delegate (List<TestSuite> x, List<TestSuite> y) { return -1 * x.Sum(t => t.ExecutionTime).CompareTo(y.Sum(t => t.ExecutionTime)); });
            for (int i = 0; i < listsCount; i++)
            {
                ConsoleLogger.Log("Final agent total time by class = " + testSuitesLists[i].Sum(x => x.ExecutionTime));
                result.Add((new List<TestCase>(testSuitesLists[i].SelectMany(x => x.TestCases)), testSuitesLists[i].Sum(x => x.ExecutionTime)));
            }

            return result;
        }
    }
}