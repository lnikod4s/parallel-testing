﻿using System;
using System.Collections.Generic;
using System.Linq;
using DistributedNUnit.Interfaces;
using DistributedNUnit.Model;

namespace DistributedNUnit.Services
{
	public class TestRunProvider : ITestRunProvider
	{
		public ITestRun CreateNewTestRun(Guid testRunId, string testList, string testAssemblyLocation, string testAssemblyName, string testAgentTag, string testLogOutputLocation, int agentTimeout, IReadOnlyList<byte> testsPackage, decimal estimatedTime, string[] excludeOutputFolders)
		{
			var newTestRun = new TestRun()
			{
				TestRunId = testRunId,
				TestList = testList,
				TestAssemblyName = testAssemblyName,
				TestAssemblyLocation = testAssemblyLocation,
				TestLogOutputLocation = testLogOutputLocation,
				TestAgentTag = testAgentTag,
				Timeout = agentTimeout,
                TestsPackage = testsPackage != null ? Convert.ToBase64String(testsPackage?.ToArray()) : null,
				InstanceId = Guid.NewGuid(),
				EstimatedExecutionTime = estimatedTime,
				ЕxcludeOutputFolders = excludeOutputFolders
			};

			return newTestRun;
		}
	}
}