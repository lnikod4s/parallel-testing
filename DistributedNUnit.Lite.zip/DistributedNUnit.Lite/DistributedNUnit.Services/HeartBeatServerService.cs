﻿using System.IO.Pipes;
using System.Threading;

namespace DistributedNUnit.Services
{
	public class HeartBeatServerService
	{
		private readonly string pipeName;
		private readonly CancellationToken cancellationToken;

		public HeartBeatServerService(string pipeName, CancellationToken cancellationToken)
		{
			this.pipeName = pipeName;
			this.cancellationToken = cancellationToken;
		}

		public void ServerHartBeatThread(object data)
		{
			NamedPipeServerStream pipeServer = new NamedPipeServerStream(this.pipeName, PipeDirection.Out);

			pipeServer.WaitForConnection();

			while (!this.cancellationToken.IsCancellationRequested)
			{
				pipeServer.Write(new byte[] { 1 }, 0, 1);

				Thread.Sleep(1000);
			}
			pipeServer.Write(new byte[] { 255 }, 0, 1);
			pipeServer.Dispose();
			return;
		}
	}
}