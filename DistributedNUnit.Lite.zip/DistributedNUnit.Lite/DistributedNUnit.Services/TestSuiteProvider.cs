﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using DistributedNUnit.Interfaces;

namespace DistributedNUnit.Services
{
	public class TestSuiteProvider : ITestSuiteProvider
	{
		private const string NunitCategoryAttributeName = "NUnit.Framework.CategoryAttribute";
		private const string NunitTestFixtureAttributeName = "NUnit.Framework.TestFixtureAttribute";
		private const string NunitTestAttributeName = "NUnit.Framework.TestAttribute";
		private readonly IReflectionProvider reflectionProvider;

		public TestSuiteProvider(IReflectionProvider reflectionProvider)
		{
			this.reflectionProvider = reflectionProvider;
		}

		public List<TestSuite> ExtractAllTestSuitesFromAssembly(string assemblyPath)
		{
			Assembly assembly = this.reflectionProvider.GetAssemblyFromFile(assemblyPath);
			var result = new List<TestSuite>();

			foreach (Type currentType in this.reflectionProvider.GetTypes(assembly))
			{
				if (this.reflectionProvider.GetCustomAttributes(currentType).Any(x => x.GetType().FullName.Equals(NunitTestFixtureAttributeName)))
				{
					// This is a Nunit test class - create new test suite for it.
					TestSuite currentTestSuite = this.CreateTestSuite(currentType);

					foreach (MethodInfo currentMethod in this.reflectionProvider.GetMethods(currentType))
					{
						if (this.reflectionProvider.GetCustomAttributes(currentMethod).Any(x => x.GetType().FullName.Equals(NunitTestAttributeName)))
						{
							// This is a Nunit test - add it to the current test class list of tests.
							TestCase currentTestCase = this.CreateTestCase(currentMethod);
							currentTestSuite.TestCases.Add(currentTestCase);
						}
					}

					if (currentTestSuite.TestCases.Count > 0)
					{
						result.Add(currentTestSuite);
					}
				}
			}

			return result;
		}

		private TestSuite CreateTestSuite(Type testClass)
		{
			var testSuite = new TestSuite()
			{
				TestCases = new List<TestCase>(),
				FullName = this.reflectionProvider.GetTypeFullName(testClass)
			};
			IEnumerable<Attribute> testSuiteCategoryAttributes = this.reflectionProvider.GetCustomAttributes(testClass).Where(x => x.GetType().FullName.Equals(NunitCategoryAttributeName));
			testSuite.Categories = this.GetCategoryNamesFromAttributes(testSuiteCategoryAttributes);

			return testSuite;
		}

		private TestCase CreateTestCase(MethodInfo testMethod)
		{
			var testCase = new TestCase()
			{
				FullName = string.Concat(this.reflectionProvider.GetMethodReflectedTypeFullName(testMethod), ".", this.reflectionProvider.GetMethodName(testMethod))
			};
			IEnumerable<Attribute> testCaseCategoryAttributes = this.reflectionProvider.GetCustomAttributes(testMethod).Where(x => x.GetType().FullName.Equals(NunitCategoryAttributeName));
			testCase.Categories = this.GetCategoryNamesFromAttributes(testCaseCategoryAttributes);

			return testCase;
		}

		private List<string> GetCategoryNamesFromAttributes(IEnumerable<Attribute> attributes)
		{
			var categoryNames = new List<string>();

			foreach (Attribute categoryAttribute in attributes)
			{
				object currentCategoryName = categoryAttribute.GetType().GetProperty("Name").GetValue(categoryAttribute, null);
				categoryNames.Add((string)currentCategoryName);
			}

			return categoryNames;
		}
	}
}