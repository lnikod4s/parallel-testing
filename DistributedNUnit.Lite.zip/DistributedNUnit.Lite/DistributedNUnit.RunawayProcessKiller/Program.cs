﻿using System;
using System.Diagnostics;

namespace DistributedNUnit.RunawayProcessKiller
{
	public class Program
	{
		public static void Main(string[] args)
		{
			if (args.Length == 0)
			{
				var nunitConsoleProcesses = Process.GetProcessesByName("nunit3-console");
				KillAll(nunitConsoleProcesses);

				var nunitAgentProcesses = Process.GetProcessesByName("nunit-agent");
				KillAll(nunitAgentProcesses);

				var dotnetCoreProcesses = Process.GetProcessesByName("dotnet");
				KillAll(dotnetCoreProcesses);

				var chromeDriverProcesses = Process.GetProcessesByName("chromedriver");
				KillAll(chromeDriverProcesses);

				var cromeProcesses = Process.GetProcessesByName("chrome");
				KillAll(cromeProcesses);
			}
			else
			{
				int processId = int.Parse(args[0]);
				ProcessUtilities.KillChromeDriverAndChild(processId);
			}

			Environment.Exit(0);
		}

		private static void KillAll(Process[] processes)
		{
			try
			{
				foreach (var process in processes)
				{
					process.Kill();
				}
			}
			catch (Exception)
			{
				// Never mind.
			}
		}
	}
}