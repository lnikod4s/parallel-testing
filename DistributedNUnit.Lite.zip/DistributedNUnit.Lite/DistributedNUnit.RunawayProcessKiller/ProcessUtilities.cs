﻿using System;
using System.Diagnostics;
using System.Management;

namespace DistributedNUnit.RunawayProcessKiller
{
	class ProcessUtilities
	{
		public static void KillChromeDriverAndChild(int pid)
		{
			try
			{
				// Cannot close 'system idle process'.
				if (pid == 0)
				{
					return;
				}
				ManagementObjectSearcher searcher = new ManagementObjectSearcher
				  ("Select * From Win32_Process Where ParentProcessID=" + pid);
				ManagementObjectCollection moc = searcher.Get();
				foreach (ManagementObject mo in moc)
				{
					KillChromeDriverAndChild(Convert.ToInt32(mo["ProcessID"]));
				}
				try
				{
					Process proc = Process.GetProcessById(pid);
					if (proc.ProcessName.Contains("chrome"))
					{
						proc.Kill();
					}
				}
				catch (ArgumentException)
				{
					// Process already exited.
				}
			}
			catch (Exception)
			{
				// Process already exited.
			}
		}
	}
}