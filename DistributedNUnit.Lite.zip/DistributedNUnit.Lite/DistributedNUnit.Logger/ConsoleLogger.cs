﻿using System;

namespace DistributedNUnit.Logger
{
	public static class ConsoleLogger
	{
		public static bool Verbose { get; set; }

		public static void Log(string message)
		{
			if (Verbose)
			{
				Console.WriteLine(message);
			}
		}

		public static void LogError(string message)
		{
			Console.WriteLine(message);
		}
	}
}