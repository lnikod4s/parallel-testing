﻿using DistributedNUnit.Infrastructure;
using DistributedNUnit.Interfaces;
using DistributedNUnit.Logger;
using DistributedNUnit.Model;
using DistributedNUnit.Model.Constants;
using DistributedNUnit.RabbitMq.Client.Incoming;
using DistributedNUnit.RabbitMq.Client.Outgoing;
using DistributedNUnit.Services;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;

namespace DistributedNUnit.TestController
{
    public class TestControllerExecutionService
	{
		public void Execute(
			string resultsFolder,
			string testAssemblyPath,
			string testCategories,
			string sharedOutputFilesLocation,
			string resultsOutputFolder,
			string testAgentTag,
			string testAgentsCount,
			string testRunTimeout,
			Guid newTestRunId,
			string failIfTestFail,
			string[] excludeOutputFolders,
			string sendLocalResources = null)
		{
			// Validate parameters and use defaults if missing.
			testRunTimeout = string.IsNullOrEmpty(testRunTimeout) ? "60" : testRunTimeout;
			testAgentsCount = string.IsNullOrEmpty(testAgentsCount) ? "1" : testAgentsCount;
            bool shouldZipPackage = string.IsNullOrEmpty(sendLocalResources) ? false : bool.Parse(sendLocalResources);

            if (resultsOutputFolder == "")
			{
				resultsOutputFolder = null;
			}

			failIfTestFail = string.IsNullOrEmpty(failIfTestFail) ? "false" : failIfTestFail;
			// Get maximum test agents count. All consumers for the provided agent tag name.
			var testAgents = new Consumer().GetConsumers($"{Queues.TestsRun}.{testAgentTag}", true);

			// In case the agents are not started the default is to assume 1.
			if (testAgents == 0)
			{
				testAgents = uint.Parse(testAgentsCount);
			}

			// Custom agents count can be provided as parameter in order to not use the maximum available agents. For ex. 1.
			if (testAgentsCount != null && uint.Parse(testAgentsCount) <= testAgents)
			{
				testAgents = uint.Parse(testAgentsCount);
			}

			// Copy the local test related files to the remote share.
			var outputFilesService = new OutputFilesService(
				new FileProvider(),
				new DirectoryProvider(),
				new PathProvider());
			string originalOutputFilesLocation = new PathProvider().GetDirectoryName(testAssemblyPath);
            if (!shouldZipPackage)
            {
                outputFilesService.CopyOutputFilesToSharedLocation(newTestRunId, sharedOutputFilesLocation, originalOutputFilesLocation);
            }

			// Generate separate test lists with equal amount of tests for each agent.
			var testListGenerator = new TestListsGenerator(new TestSuiteProvider(new ReflectionProvider()), new TestSuiteFilterService());
			var testExecutionTimes = new Dictionary<string, decimal>();
			if (testAgents > 1)
			{
				testExecutionTimes = new RedisProvider().GetTestsTimes();
			}			
			var testLists = testListGenerator.Generate((int)testAgents, testAssemblyPath, testCategories, testExecutionTimes);

			if (testLists.Count == 0 || (testLists.Count == 1 && testLists.ElementAt(0).Tests.Length < 3))
			{
				Environment.Exit(0);
			}

            IReadOnlyList<byte> package = null;
            if (shouldZipPackage)
            {
                var zipTestPackageProvider = new ZipTestPackageProvider();
                package = zipTestPackageProvider.Create(originalOutputFilesLocation);
                sharedOutputFilesLocation = "local";
            }

            int testAgentsTimeout = int.Parse(testRunTimeout);
            List<ITestRun> testRuns = new List<ITestRun>();
            var testRunProvider = new TestRunProvider();

            // Generate separate test run for each of the lists in order to send it to the agent.
            foreach (var testList in testLists)
			{
				// If all tests to be run are less than the provided agents some of the lists may be empty and we don't want to run them.
				if (testList.Tests.Trim(Environment.NewLine.ToCharArray()) != string.Empty)
				{
					testRuns.Add(testRunProvider.CreateNewTestRun(
						newTestRunId,
						testList.Tests,
						sharedOutputFilesLocation,
						new PathProvider().GetFileName(testAssemblyPath),
						testAgentTag,
						resultsOutputFolder,
						testAgentsTimeout,
                        package,
						testList.Time,
						excludeOutputFolders));
				}
			}

			if (testRuns.Count == 0)
			{
				Environment.Exit(0);
			}

			// Start listening for the incoming console output from the agents and print it to the local console.
			var consumer = new Consumer();
			var tokenSource = new CancellationTokenSource();
			List<string> allTests = testRuns.SelectMany(x => x.TestList.Split(Environment.NewLine).ToList()).Where(x => x.Length > 0).ToList();

			Task.Run(() => consumer.ProcessTestRunLogMessages(testAgentTag, newTestRunId, allTests, tokenSource.Token), tokenSource.Token);

			// Send all test runs to the agents to execute.
			Dictionary<Guid, decimal> estimatedTimes = new Dictionary<Guid, decimal>();
			var producer = new Producer();
			foreach (var testRun in testRuns)
			{
				estimatedTimes.Add(testRun.InstanceId, testRun.EstimatedExecutionTime);
				producer.SendTestRunMessage((TestRun)testRun);
			}

			// Start the heart beat monitoring.
			this.StartTestRunHeartBeat(newTestRunId, testAgentTag, testRuns.Count, tokenSource.Token);

			// Start waiting for all of the test results to arrive and cancel the console listener.
			var success = consumer.ProcessTestRunResultMessages(
				testAgentTag,
				newTestRunId,
				(uint)testRuns.Count,
				resultsFolder,
				int.Parse(testRunTimeout),
				estimatedTimes);

			// Cancel the thread readin the console output.
			tokenSource.Cancel();

			if (!success.Timeout)
			{
				throw new TimeoutException("Test run has timed out or some agents timed out or have been aborted!");
			}

			if (!success.TestResult && bool.Parse(failIfTestFail))
			{
				throw new TestFailException();
			}
		}

		public void StartTestRunHeartBeat(Guid testRunId, string testAgentTag, int runsCount, CancellationToken cancellationToken)
		{
			ConsoleLogger.Log("[*] Starting the hearbeat monitoring.....");
			HeartBeatServerService heartBeatServer = new HeartBeatServerService(testRunId.ToString(), cancellationToken);
			Thread server = new Thread(heartBeatServer.ServerHartBeatThread);

			server.Start();

			try
			{
				var processProvider = new ProcessProvider();
				string path = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "DistributedNUnit.TestControllerHeartBeat.dll");
				string arguments = $"{ path } -t { testRunId } -a { testAgentTag } -c { runsCount }";
				processProvider.StartParentlessProcess("dotnet.exe", arguments);

				ConsoleLogger.Log($"[*] Started from { path }");
			}
			catch (Exception ex)
			{
				ConsoleLogger.Log("[x] Error starting the hearbeat monitor: " + ex.ToString());
			}
		}

		private void StopTestRunHeartBeat(int? processId)
		{
			Thread.Sleep(10000); // wait for it to exit.
			if (processId.HasValue)
			{
				try
				{
					var processProvider = new ProcessProvider();
					processProvider.KillProcess(processId.Value);
				}
				catch (Exception)
				{
					// Never mind, it may has exited by his own.
				}
			}
		}
	}
}