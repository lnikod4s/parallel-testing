﻿using System;
using DistributedNUnit.Logger;
using DistributedNUnit.Model;
using DistributedNUnit.RabbitMq.Client.Outgoing;
using Microsoft.Extensions.CommandLineUtils;

namespace DistributedNUnit.TestController
{
	class Program
    {
		private static TestControllerExecutionService testControllerExecutionService;

		static void Main(params string[] args)
        {	
			try
			{
				CommandLineApplication commandLineApplication =	new CommandLineApplication(throwOnUnexpectedArg: true);

				CommandOption resultsFolder = commandLineApplication.Option(
					"-$|-r |--resultsFolder <.workspase/results/>",
					"The local folder in which the test results will be saved.",
					CommandOptionType.SingleValue);

				CommandOption testAssemblyPath = commandLineApplication.Option(
					"-$|-t |--testAssembly <.workspase/bin/release/unit.tests.dll>",
					"The test assembly path to execute tests from.",
					CommandOptionType.SingleValue);

				CommandOption testCategories = commandLineApplication.Option(
					"-$|-c |--testCategories <SmokeTests_Category1>",
					"The test categories from which the tests will run. Separated by _",
					CommandOptionType.SingleValue);

				CommandOption sharedOutputFilesLocation = commandLineApplication.Option(
					"-$|-s |--sharedOutputFilesLocation <//fileserver/testrun/>",
					"The shared folder from which the agents will run the tests.",
					CommandOptionType.SingleValue);

				CommandOption resultsOutputFolder = commandLineApplication.Option(
					"-$|-f |--resultsOutputFolder <//fileserver/testrun/outputFiles/>",
					"The shared folder in which the tests can save stuff during execution.",
					CommandOptionType.SingleValue);

				CommandOption agentTagName = commandLineApplication.Option(
	                "-$|-a |--agentTagName <UnitTestsAgent1>",
	                "The tag for the test agent to run the tests on",
	                CommandOptionType.SingleValue);

				CommandOption testAgentsCount = commandLineApplication.Option(
					"-$|-x |--testAgentsCount <5>",
					"Specify how many test agents to distribute to. The default is the maximum subscribed to the tag.",
					CommandOptionType.SingleValue);

				CommandOption testRunTimeout = commandLineApplication.Option(
					"-$|-e |--testRunTimeout <180>",
					"Specify how many minutes to wait wintil the run is aborted.",
					CommandOptionType.SingleValue);

				CommandOption failIfTestFail = commandLineApplication.Option(
					"-$|-y |--shouldFailIfTestsFail <false>",
					"Specify wheather should the controller return fail code if any test form the runs have not passed.",
					CommandOptionType.SingleValue);

				CommandOption verboseLogging = commandLineApplication.Option(
					"-$|-v |--verboseLogging <false>",
					"Specify wheather should the controller log internal messages on the console.",
					CommandOptionType.SingleValue);

                CommandOption sendLocalRsources = commandLineApplication.Option(
                    "-$|-l |--localResources <false>",
                    "Specify wheather tests files are zipped and send locally to the agents.",
                    CommandOptionType.SingleValue);

				CommandOption excludeOutputFolders = commandLineApplication.Option(
					"-$|-excl |--excludeOutputFolders <folderName1>|<folderName2>",
					"List with folder names that will not be copied to the test output.",
					CommandOptionType.SingleValue);

				commandLineApplication.HelpOption("-? | -h | --help");

				testControllerExecutionService = new TestControllerExecutionService();
				Guid currentTestRunId = Guid.NewGuid();

				commandLineApplication.OnExecute(() =>
				{

					if (verboseLogging.HasValue())
					{
						ConsoleLogger.Verbose = bool.Parse(verboseLogging.Value());
					}

					string[] excludeFolders = new string[0];

					if (excludeOutputFolders.HasValue())
					{
						excludeFolders = excludeOutputFolders.Value()
							.Split(new char[] { '|' }, StringSplitOptions.RemoveEmptyEntries);
					}					

					testControllerExecutionService.Execute(
						resultsFolder.Value(),
						testAssemblyPath.Value(),
						testCategories.Value(),
						sharedOutputFilesLocation.Value(),
						resultsOutputFolder.Value(),
						agentTagName.Value(),
						testAgentsCount.Value(),
						testRunTimeout.Value(),
						currentTestRunId,
						failIfTestFail.Value(),
						excludeFolders,
						sendLocalRsources.Value());
					return 0;
				});
				commandLineApplication.Execute(args);
			}
			catch (TestFailException)
			{
				Environment.Exit(-1);
			}
			catch (Exception ex)
			{
				new Producer().SendErrorMessage(ex.ToString());
				Console.WriteLine(ex.ToString());
				Environment.Exit(-1);
			}
        }
	}
}