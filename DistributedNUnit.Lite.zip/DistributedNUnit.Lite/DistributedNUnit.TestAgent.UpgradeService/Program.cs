﻿using System;
using DistributedNUnit.RabbitMq.Client.Incoming;

namespace DistributedNUnit.TestAgent.UpgradeService
{
	class Program
    {
        static void Main(string[] args)
        {
			new Consumer().ProcessAgentVersionUpgradeMessages(Environment.MachineName);
		}
    }
}