﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using DistributedNUnit.Model;
using DistributedNUnit.Model.Constants;
using Newtonsoft.Json;
using RabbitMQ.Client;

namespace DistributedNUnit.RabbitMq.Client.Outgoing
{
	public class Producer
	{
		// The test controller only sends those messages.
		public void SendTestRunMessage(TestRun testRun)
		{
			var factory = new ConnectionFactory()
			{
				HostName = Factory.HostName,
				UserName = Factory.UserName,
				Password = Factory.Password,
				VirtualHost = Factory.VirtualHost,
				Port = Factory.Port
			};

			using (var connection = factory.CreateConnection())
			using (var channel = connection.CreateModel())
			{
				channel.ExchangeDeclare(exchange: Exchanges.NewTestRun, type: "direct", durable: true);

				string message = JsonConvert.SerializeObject(testRun);
				var body = Encoding.UTF8.GetBytes(message);

				var properties = channel.CreateBasicProperties();
				properties.Persistent = false;
				properties.ContentType = "application/json";

				channel.BasicPublish(exchange: Exchanges.NewTestRun,
									 routingKey: testRun.TestAgentTag,
									 basicProperties: properties,
									 body: body);
			}
		}

		public void SendTestRunConsoleOutputMessage(string testRunConsoleOutputLine, Guid testRunId)
		{
			var factory = new ConnectionFactory()
			{
				HostName = Factory.HostName,
				UserName = Factory.UserName,
				Password = Factory.Password,
				VirtualHost = Factory.VirtualHost,
				Port = Factory.Port
			};

			try
			{
				using (var connection = factory.CreateConnection())
				using (var channel = connection.CreateModel())
				{
					channel.ExchangeDeclare(exchange: Exchanges.ConsoleOutput, type: "direct", durable: true);

					var testRunConsoleOutput = new TestRunConsoleOutput()
					{
						TestRunId = testRunId,
						ConsoleMessage = Environment.MachineName + " : " + testRunConsoleOutputLine
					};
					string message = JsonConvert.SerializeObject(testRunConsoleOutput);
					var body = Encoding.UTF8.GetBytes(message);

					var properties = channel.CreateBasicProperties();
					properties.Persistent = false;
					properties.ContentType = "application/json";

					channel.BasicPublish(exchange: Exchanges.ConsoleOutput,
										 routingKey: testRunConsoleOutput.TestRunId.ToString(),
										 basicProperties: properties,
										 body: body);
				}
			}
			catch (Exception)
			{
				// We dont care exception to avoid crash the agent.
			}
		}

		public void SendTestRunResultMessage(TestRunResult testRunResult, string tagName)
		{
			var factory = new ConnectionFactory()
			{
				HostName = Factory.HostName,
				UserName = Factory.UserName,
				Password = Factory.Password,
				VirtualHost = Factory.VirtualHost,
				Port = Factory.Port
			};

			try
			{
				using (var connection = factory.CreateConnection())
				using (var channel = connection.CreateModel())
				{
					channel.ExchangeDeclare(exchange: Exchanges.TestRunResult, type: "direct", durable: true);

					if (!testRunResult.Status.Contains("Fail"))
					{
						string queueName = $"{Queues.TestsRunTestsResults}.{tagName}.{testRunResult.TestRunId}";
						var args = new Dictionary<string, object>
						{
							{ "x-expires", (int)TimeSpan.FromSeconds(60).TotalMilliseconds }
						};

						channel.QueueDeclare(queue: queueName,
										 durable: true,
										 exclusive: false,
										 autoDelete: true,
										 arguments: args);

						channel.QueueBind(queue: queueName,
										  exchange: Exchanges.TestRunResult,
										  routingKey: testRunResult.TestRunId.ToString());
					}			

					string message = JsonConvert.SerializeObject(testRunResult);
					var body = Encoding.UTF8.GetBytes(message);

					var properties = channel.CreateBasicProperties();
					properties.Persistent = false;
					properties.ContentType = "application/json";

					channel.BasicPublish(exchange: Exchanges.TestRunResult,
										 routingKey: testRunResult.TestRunId.ToString(),
										 basicProperties: properties,
										 body: body);
				}
			}
			catch (Exception)
			{
				// We dont care exception to avoid crash the agent.
			}
		}

		public void SendErrorMessage(string message)
		{
			var factory = new ConnectionFactory()
			{
				HostName = Factory.HostName,
				UserName = Factory.UserName,
				Password = Factory.Password,
				VirtualHost = Factory.VirtualHost,
				Port = Factory.Port
			};

			try
			{
				string queueName = Queues.ErrorQueue;
				using (var connection = factory.CreateConnection())
				using (var channel = connection.CreateModel())
				{
					channel.QueueDeclare(queue: queueName,
										 durable: true,
										 exclusive: false,
										 autoDelete: false,
										 arguments: null);
					var body = Encoding.UTF8.GetBytes(message);

					var properties = channel.CreateBasicProperties();
					properties.Persistent = false;
					properties.ContentType = "application/json";

					channel.BasicPublish(exchange: "",
										 routingKey: queueName,
										 basicProperties: properties,
										 body: body);
				}
			}
			catch (Exception)
			{
				// We dont care exception to avoid crash the agent.
			}
		}

		public void SendTestsRunAbortMessage(Guid testRunId, string tagName)
		{
			string queueName = $"{Queues.TestRunCancelation}.{tagName}.{Guid.NewGuid().ToString()}.{"ping"}";
			string exchangeName = $"{Exchanges.CancelationTestRun}.{testRunId}";

			var factory = new ConnectionFactory()
			{
				HostName = Factory.HostName,
				UserName = Factory.UserName,
				Password = Factory.Password,
				VirtualHost = Factory.VirtualHost,
				Port = Factory.Port
			};

			try
			{
				using (var connection = factory.CreateConnection())
				using (var channel = connection.CreateModel())
				{
					var args = new Dictionary<string, object>
						{
							{ "x-expires", (int)TimeSpan.FromSeconds(10).TotalMilliseconds }
						};

					channel.ExchangeDeclare(exchange: exchangeName,
											type: "fanout",
											durable: true,
											autoDelete: true,
											arguments: args);

					channel.QueueDeclare(queue: queueName,
									 durable: true,
									 exclusive: false,
									 autoDelete: true,
									 arguments: args);

					channel.BasicQos(prefetchSize: 0, prefetchCount: 1, global: false);

					channel.QueueBind(queue: queueName,
									  exchange: exchangeName,
									  routingKey: testRunId.ToString());

					string message = JsonConvert.SerializeObject("Abort");
					var body = Encoding.UTF8.GetBytes(message);

					var properties = channel.CreateBasicProperties();
					properties.Persistent = false;
					properties.ContentType = "application/json";

					channel.BasicPublish(exchange: exchangeName,
										 routingKey: testRunId.ToString(),
										 basicProperties: properties,
										 body: body);
					Thread.Sleep(500);
					channel.BasicPublish(exchange: exchangeName,
										 routingKey: testRunId.ToString(),
										 basicProperties: properties,
										 body: body);
				}
			}
			catch (Exception)
			{
				// We dont care exception this is final;
			}
		}

		public void SendTestAgentVersionUpgradeMessage(UpgradeMessage upgradeMessage, string machineName)
		{
			var factory = new ConnectionFactory()
			{
				HostName = Factory.HostName,
				UserName = Factory.UserName,
				Password = Factory.Password,
				VirtualHost = Factory.VirtualHost,
				Port = Factory.Port
			};

			using (var connection = factory.CreateConnection())
			using (var channel = connection.CreateModel())
			{
				channel.ExchangeDeclare(exchange: Exchanges.AgentVersionUpgrade, type: "direct", durable: true);

				string message = JsonConvert.SerializeObject(upgradeMessage);
				var body = Encoding.UTF8.GetBytes(message);

				var properties = channel.CreateBasicProperties();
				properties.Persistent = false;
				properties.ContentType = "application/json";

				channel.BasicPublish(exchange: Exchanges.AgentVersionUpgrade,
									 routingKey: machineName,
									 basicProperties: properties,
									 body: body);
			}
		}
	}
}