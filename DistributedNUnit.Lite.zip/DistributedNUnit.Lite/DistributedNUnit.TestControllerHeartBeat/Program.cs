﻿using DistributedNUnit.Model.Constants;
using DistributedNUnit.RabbitMq.Client.Incoming;
using DistributedNUnit.RabbitMq.Client.Outgoing;
using Microsoft.Extensions.CommandLineUtils;
using System;
using System.Diagnostics;
using System.IO.Pipes;
using System.Threading;

namespace DistributedNUnit.TestControllerHeartBeat
{
	class Program
	{
		static void Main(string[] args)
		{
			try
			{
				CommandLineApplication commandLineApplication = new CommandLineApplication(throwOnUnexpectedArg: true);

				CommandOption testRunId = commandLineApplication.Option(
					"-$|-t |--testRunId <d7ce7617-8989-4f32-9ebd-458c6c609d95>",
					"The test run Id to be monitored.",
					CommandOptionType.SingleValue);

				CommandOption agentTagName = commandLineApplication.Option(
					"-$|-a |--agentTagName <UnitTestsAgent1>",
					"The tag for the test agent for which the test run is started.",
					CommandOptionType.SingleValue);

				CommandOption runsCount = commandLineApplication.Option(
					"-$|-c |--count <5>",
					"The numner of agent runs started started.",
					CommandOptionType.SingleValue);

				commandLineApplication.HelpOption("-? | -h | --help");

				commandLineApplication.OnExecute(() =>
				{
					int count = int.Parse(runsCount.Value());
					string testRunIdString = testRunId.Value();
					Thread.Sleep(1000);

					try
					{
						using (NamedPipeClientStream pipeClient = new NamedPipeClientStream(".", testRunIdString, PipeDirection.In))
						{
							int result = 1;
							pipeClient.Connect();
							while (pipeClient.IsConnected && result > 0 && result != 255)
							{
								result = pipeClient.ReadByte();

								Thread.Sleep(1000);
							}
							if (result != 255)
							{
								AbortTestRun(testRunIdString, agentTagName.Value(), count);
							}						
						}
						
						Environment.Exit(0);
					}
					catch (Exception)
					{
						AbortTestRun(testRunIdString, agentTagName.Value(), count);
						Environment.Exit(0);
					}
					AbortTestRun(testRunIdString, agentTagName.Value(), count);
					return 0;
				});
				commandLineApplication.Execute(args);
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.ToString());
				Environment.Exit(-1);
			}
		}

		static void AbortTestRun(string testRunId, string agentTagName, int count)
		{
			try
			{
				new Consumer().RemoveUnprocessedMessagesForTestRun(Guid.Parse(testRunId), $"{Queues.TestsRun}.{agentTagName}");
			}
			catch (Exception)
			{
				Environment.Exit(-1);
			}

			try
			{
				new Producer().SendTestsRunAbortMessage(Guid.Parse(testRunId), agentTagName);
			}
			catch (Exception)
			{
				// It's fine, no agents are left behind running tests after finish;
				new Producer().SendTestsRunAbortMessage(Guid.Parse(testRunId), agentTagName);
			}
		}
	}
}