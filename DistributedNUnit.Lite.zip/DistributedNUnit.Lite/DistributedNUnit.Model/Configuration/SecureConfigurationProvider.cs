﻿using System;
using System.IO;
using System.Text;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.Json;

namespace DistributedNUnit.Model.Configuration
{
	public class SecureConfigurationProvider : JsonConfigurationProvider
	{
		public SecureConfigurationProvider(SecureConfigurationSource source) : base(source)
		{
		}

		public override void Load(Stream stream)
		{
			// Let the base class do the heavy lifting.
			base.Load(stream);

			// Do decryption here, you can tap into the Data property like so:

			//Data["abc:password"] = "";//MyEncryptionLibrary.Decrypt(Data["abc:password"]);
			Data["userName"] = DecryptData(Data["userName"]);
			Data["password"] = DecryptData(Data["password"]);

			// But you have to make your own MyEncryptionLibrary, not included here
		}

		public class SecureConfigurationSource : JsonConfigurationSource
		{
			public override IConfigurationProvider Build(IConfigurationBuilder builder)
			{
				EnsureDefaults(builder);
				return new SecureConfigurationProvider(this);
			}
		}

		private string DecryptData(string encodedData)
		{
			byte[] data = Convert.FromBase64String(encodedData);
			string decodedString = Encoding.UTF8.GetString(data);

			return decodedString;
		}
	}
}