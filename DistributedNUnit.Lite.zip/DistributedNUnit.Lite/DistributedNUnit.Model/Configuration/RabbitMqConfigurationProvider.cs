﻿using System.IO;
using System.Reflection;
using Microsoft.Extensions.Configuration;

namespace DistributedNUnit.Model.Configuration
{
	public static class RabbitMqConfigurationProvider
    {
		public static IConfigurationRoot Configuration { get; set; }

		static RabbitMqConfigurationProvider()
		{
			var builder = new ConfigurationBuilder()
			 .SetBasePath(Path.GetDirectoryName(Assembly.GetEntryAssembly().Location))
			.AddSecureJsonFile("Configuration\\appsettings.json", false, false);

			Configuration = builder.Build();
		}
	}
}