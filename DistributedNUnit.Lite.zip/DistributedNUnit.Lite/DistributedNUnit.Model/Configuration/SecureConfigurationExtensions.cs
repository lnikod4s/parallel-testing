﻿using System;
using Microsoft.Extensions.Configuration;
using static DistributedNUnit.Model.Configuration.SecureConfigurationProvider;

namespace DistributedNUnit.Model.Configuration
{
	public static class SecureConfigurationExtensions
	{
		public static IConfigurationBuilder AddSecureJsonFile(this IConfigurationBuilder builder, string path, bool optional,
			bool reloadOnChange)
		{
			if (builder == null)
			{
				throw new ArgumentNullException(nameof(builder));
			}

			if (string.IsNullOrEmpty(path))
			{
				throw new ArgumentException("File path must be a non-empty string.");
			}

			var source = new SecureConfigurationSource
			{
				FileProvider = null,
				Path = path,
				Optional = optional,
				ReloadOnChange = reloadOnChange
			};

			source.ResolveFileProvider();
			builder.Add(source);
			return builder;
		}
	}
}