﻿namespace DistributedNUnit.Model
{
	public class UpgradeMessage
    {
		public string AgentPath { get; set; }
    }
}