﻿using System;

namespace DistributedNUnit.Model
{
	public class TestRunConsoleOutput
    {
		public Guid TestRunId { get; set; }

		public string ConsoleMessage { get; set; }
    }
}