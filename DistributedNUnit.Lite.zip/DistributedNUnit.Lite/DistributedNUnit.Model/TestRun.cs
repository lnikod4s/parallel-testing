﻿using DistributedNUnit.Interfaces;
using System;

namespace DistributedNUnit.Model
{
    public class TestRun : ITestRun
	{
		public Guid TestRunId { get; set; }

		public string TestList { get; set; }

		public string TestAssemblyLocation { get; set; }

		public string TestAssemblyName { get; set; }

		public string TestLogOutputLocation { get; set; }

		public string TestAgentTag { get; set; }

		public int Timeout { get; set; }

        public string TestsPackage { get; set; }

		public decimal EstimatedExecutionTime { get; set; }

		public Guid InstanceId { get; set; }

		public string[] ЕxcludeOutputFolders { get; set; }
	}
}