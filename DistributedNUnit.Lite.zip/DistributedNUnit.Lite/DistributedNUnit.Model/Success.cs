﻿namespace DistributedNUnit.Model
{
	public class Success
    {
		public bool Timeout { get; set; }

		public bool TestResult { get; set; }
    }
}