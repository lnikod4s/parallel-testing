﻿using System;

namespace DistributedNUnit.Model
{
	public class TestRunResult
    {
		public Guid TestRunId { get; set; }

		public string Status { get; set; }

		public string TestResults { get; set; }

		public bool IsTestsResultSuccess { get; set; }

		public Guid ResultId { get; set; }

		public double TimeTaken { get; set; }
	}
}