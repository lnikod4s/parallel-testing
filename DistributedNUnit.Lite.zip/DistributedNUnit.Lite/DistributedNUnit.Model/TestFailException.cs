﻿using System;

namespace DistributedNUnit.Model
{
	public class TestFailException : Exception
    {
    }
}