﻿namespace DistributedNUnit.Model.Constants
{
	public class Queues
    {
		public const string TestsRun = "dn.testsRun";
		public const string TestsRunConsoleOutput = "dn.testsRunConsoleOutput";
		public const string TestsRunTestsResults = "dn.testsRunTestsResults";
		public const string ErrorQueue = "dn.Errors";
		public const string TestRunCancelation = "dn.testsRunCancelation";
		public const string AgentVersionUpgradeQueue = "dn.AgentUpgrade";
	}
}