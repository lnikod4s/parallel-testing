﻿namespace DistributedNUnit.Model.Constants
{
	public class Exchanges
    {
		public const string NewTestRun = "NewTestRun_Exchange";
		public const string ConsoleOutput = "ConsoleOutput_Exchange";
		public const string TestRunResult = "TestRunResult_Exchange";
		public const string CancelationTestRun = "CancelationTestRun_Exchange";
		public const string AgentVersionUpgrade = "AgentUpgrade_Exchange";
	}
}