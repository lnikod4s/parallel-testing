﻿using DistributedNUnit.Model.Configuration;

namespace DistributedNUnit.Model.Constants
{
	public class Factory
    {
		public const string HostName = "lstestsmq.dev.progress.com";
		public const string VirtualHost = "Nunit";
		public const int Port = 5672;

		public static string UserName
		{
			get
			{
				return RabbitMqConfigurationProvider.Configuration["username"];
			}
		}

		public static string Password
		{
			get
			{
				return RabbitMqConfigurationProvider.Configuration["password"];
			}
		}
	}
}