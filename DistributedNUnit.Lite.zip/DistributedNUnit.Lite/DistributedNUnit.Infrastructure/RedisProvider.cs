﻿using System.Collections.Generic;
using System.Threading;
using StackExchange.Redis;
using StackExchange.Redis.Extensions.Core;
using StackExchange.Redis.Extensions.Newtonsoft;

namespace DistributedNUnit.Infrastructure
{
	public class RedisProvider
    {
		private readonly ConnectionMultiplexer connectionMultiplexer;

		public RedisProvider()
		{
			this.connectionMultiplexer = ConnectionMultiplexer.Connect("172.31.80.127:6380");
		}

		public Dictionary<string, decimal> GetTestsTimes()
		{
			Dictionary<string, decimal> result = new Dictionary<string, decimal>();
			int retryCount = 10;

			while (retryCount-- > 0)
			{
				try
				{
					var serializer = new NewtonsoftSerializer();
					var cacheClient = new StackExchangeRedisCacheClient(this.connectionMultiplexer, serializer);

					var allKeys = cacheClient.SearchKeys("*");
					var allValues = cacheClient.GetAll<decimal>(allKeys);

					return new Dictionary<string, decimal>(allValues);
				}
				catch (RedisTimeoutException)
				{
					Thread.Sleep(1000);
					continue;
				}
			}

			return result;
		}

		public void SaveTestsTimes(Dictionary<string, decimal> testsTimes)
		{
			int retryCount = 10;

			while (retryCount-- > 0)
			{
				try
				{
					var serializer = new NewtonsoftSerializer();
					var cacheClient = new StackExchangeRedisCacheClient(this.connectionMultiplexer, serializer);

					var allExisting = cacheClient.GetAll<decimal>(new List<string>(testsTimes.Keys));

					foreach (var test in testsTimes)
					{
						if (allExisting.ContainsKey(test.Key))
						{
							var oldValue = allExisting[test.Key];
							decimal newValue = (oldValue + test.Value) / 2.0m;
							cacheClient.Replace(test.Key, newValue);
						}
						else
						{
							cacheClient.Add(test.Key, test.Value);
						}
					}
					break;
				}
				catch (RedisTimeoutException)
				{
					Thread.Sleep(1000);
					continue;
				}
			}
		}
    }
}