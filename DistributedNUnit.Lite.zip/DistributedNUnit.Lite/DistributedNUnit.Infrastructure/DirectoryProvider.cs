﻿using System.IO;
using DistributedNUnit.Interfaces;

namespace DistributedNUnit.Infrastructure
{
    public class DirectoryProvider : IDirectoryProvider
    {
        public bool DoesDirectoryExists(string path)
        {
            return Directory.Exists(path);
        }

        public string[] GetFiles(string path)
        {
            return Directory.GetFiles(path);
        }

        public void CreateDirectory(string path)
        {
            Directory.CreateDirectory(path);
        }
    }
}