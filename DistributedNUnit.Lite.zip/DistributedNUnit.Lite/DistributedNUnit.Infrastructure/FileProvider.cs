﻿using System.IO;
using DistributedNUnit.Interfaces;

namespace DistributedNUnit.Infrastructure
{
    public class FileProvider : IFileProvider
    {
        public void Copy(string sourceFileName, string destFileName, bool overwrite)
        {
            File.Copy(sourceFileName, destFileName, overwrite);
        }

        public void WriteAllText(string path, string contents)
        {
            File.WriteAllText(path, contents);
        }

        public string ReadAllText(string path)
        {
            return File.ReadAllText(path);
        }

        public void Delete(string path)
        {
            File.Delete(path);
        }

        public bool IsWithExtension(string filePath, string extension)
        {
            if (!File.Exists(filePath))
            {
                throw new FileNotFoundException("The specified file does not exist", filePath);
            }
            var fileInfo = new FileInfo(filePath);
            return fileInfo.Extension.Equals(extension);
        }
    }
}