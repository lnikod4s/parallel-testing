﻿using DistributedNUnit.Interfaces;

namespace DistributedNUnit.Infrastructure
{
	public class ConsoleProvider : IConsoleProvider
	{
		public void WriteLine(string format, params string[] arguments)
		{
			System.Console.WriteLine(format, arguments);
		}

		public void WriteLine(string message)
		{
			System.Console.WriteLine(message);
		}

		public void Write(string format, params string[] arguments)
		{
			System.Console.Write(format, arguments);
		}

		public void Write(string message)
		{
			System.Console.Write(message);
		}

		public string ReadLine()
		{
			return System.Console.ReadLine();
		}
	}
}