﻿using System;
using System.IO;
using System.Threading;
using DistributedNUnit.Interfaces;

namespace DistributedNUnit.Infrastructure
{
	public class NUnitRunner : INUnitRunner
	{
		private const string NUnitRunnerArgumetsFormat = " {0} --result:{1};format=nunit2 --testlist={2} --dispose-runners --workers=1 --noheader --labels=After --framework=net-4.5";

		private readonly IProcessProvider processStarter;
		private readonly IFileProvider fileProvider;
		private readonly IPathProvider pathProvider;
		private readonly IConsoleProvider consoleProvider;
		private readonly string nunitConsoleExePath;
		private Guid currentTestRunId;

		public NUnitRunner(
			IProcessProvider processStarter,
			IFileProvider fileProvider,
			IPathProvider pathProvider,
			IConsoleProvider consoleProvider)
		{
			this.processStarter = processStarter;
			this.fileProvider = fileProvider;
			this.pathProvider = pathProvider;
			this.consoleProvider = consoleProvider;
			this.nunitConsoleExePath = @"C:\Program Files (x86)\NUnit.org\nunit-console\";
		}

		public string ExecuteNUnitTests(string testListFilePath, string workingDir, Guid testRunId, string testsAssembly, Action<string> dispatchConsoleOutput, CancellationToken cancellationToken, out bool testResultsStatus)
		{
            testResultsStatus = false;
            this.currentTestRunId = testRunId;
			string testResultsFilePath = this.pathProvider.GetTempFileName();
			string arguments = this.BuildNUnitRunnerArguments(testListFilePath, testResultsFilePath, testsAssembly);
			string nunitConsoleExecutable = Path.Combine(this.nunitConsoleExePath, "nunit3-console.exe");
			int exitCode = this.processStarter.StartProcess(
				nunitConsoleExecutable,
				workingDir,
				arguments,
				cancellationToken,
				dispatchConsoleOutput,
				this.LogErrorOutput);

			string testTestResults = string.Empty;

			if (exitCode == 0)
			{
				testTestResults = this.fileProvider.ReadAllText(testResultsFilePath);
                testResultsStatus = new NunitTestResultsProvider().GetTestResultsStatus(testTestResults);
            }

			cancellationToken.ThrowIfCancellationRequested();
			return testTestResults;
		}

		public void LogErrorOutput(string message)
		{
			this.consoleProvider.WriteLine(message);
		}

		private string BuildNUnitRunnerArguments(string testListFilePath, string testResultsFilePath, string testsAssembly)
		{
			string arguments = string.Format(NUnitRunnerArgumetsFormat, testsAssembly, testResultsFilePath, testListFilePath);
			return arguments;
		}
	}
}