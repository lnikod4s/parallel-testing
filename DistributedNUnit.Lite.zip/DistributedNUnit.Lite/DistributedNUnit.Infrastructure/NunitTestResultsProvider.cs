﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Serialization;

namespace DistributedNUnit.Infrastructure
{
	public class NunitTestResultsProvider
    {
		public bool GetTestResultsStatus(string testResults)
		{
			try
			{
				var serializer = new XmlSerializer(typeof(resultType));

				using (TextReader reader = new StringReader(testResults))
				{
					var result = (resultType)serializer.Deserialize(reader);

					return result.failures == 0 && result.errors == 0 && result.inconclusive == 0 && result.skipped == 0 && result.notrun == 0;
				}
			}
			catch (Exception)
			{
				return false;
			}
		}

		public Dictionary<string, decimal> GetTestMethodsExecutionTime(string testResults)
		{
			var serializer = new XmlSerializer(typeof(resultType));
			Dictionary<string, decimal> resultDic = new Dictionary<string, decimal>();

			using (TextReader reader = new StringReader(testResults))
			{
				var topResult = (resultType)serializer.Deserialize(reader);
				this.AddTestCase(resultDic, topResult.testsuite.results);
			}

			return resultDic;
		}

		private void AddTestCase(Dictionary<string, decimal> resultDic, resultsType topResult)
		{
			var items = topResult.Items;
			foreach (var item in items)
			{
				if (typeof(testcaseType).IsAssignableFrom(item.GetType()))
				{
					if (((testcaseType)item).result == "Success")
					{
						resultDic.Add(((testcaseType)item).name, decimal.Parse(((testcaseType)item).time));
					}
				}
				else
				{
					this.AddTestCase(resultDic, ((testsuiteType)item).results);
				}
			}
		}

		public Dictionary<string, decimal> GetTestClassesExecutionTime(string testResults)
		{
			var serializer = new XmlSerializer(typeof(resultType));
			Dictionary<string, decimal> resultDic = new Dictionary<string, decimal>();

			using (TextReader reader = new StringReader(testResults))
			{
				var topResult = (resultType)serializer.Deserialize(reader);
				this.AddTestClass(resultDic, topResult.testsuite.results);
			}

			return resultDic;
		}

		private void AddTestClass(Dictionary<string, decimal> resultDic, resultsType topResult)
		{
			var items = topResult.Items;
			foreach (var item in items)
			{
				if (typeof(testsuiteType).IsAssignableFrom(item.GetType()) && ((testsuiteType)item).results.Items.Any(x => typeof(testcaseType).IsAssignableFrom(x.GetType())))
				{
					if (((testsuiteType)item).result == "Success")
					{
						var firstTest = ((testsuiteType)item).results.Items.First();
						var nameSpaces = ((testcaseType)firstTest).name.Split('.').ToList();
						nameSpaces.RemoveAt(nameSpaces.Count - 1);
						string name = string.Join(".", nameSpaces);
						resultDic.Add(name, decimal.Parse(((testsuiteType)item).time));
					}
				}
				else
				{
					this.AddTestClass(resultDic, ((testsuiteType)item).results);
				}
			}
		}
	}
}