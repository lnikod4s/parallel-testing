﻿using DistributedNUnit.Interfaces;
using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;

namespace DistributedNUnit.Infrastructure
{
    public class ZipTestPackageProvider : IZipTestPackageProvider
    {
        public IReadOnlyList<byte> Create(string folderLocation)
        {
            var pathProvider = new PathProvider();
            string tempFolder = pathProvider.GetTempFolderPath();
            string zipPath = Path.Combine(tempFolder, Guid.NewGuid().ToString() + ".zip");

            ZipFile.CreateFromDirectory(folderLocation, zipPath);

            return File.ReadAllBytes(zipPath);
        }
    }
}