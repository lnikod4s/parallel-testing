﻿using System;
using System.Collections.Generic;
using System.Reflection;
using DistributedNUnit.Interfaces;

namespace DistributedNUnit.Infrastructure
{
	public class ReflectionProvider : IReflectionProvider
	{
		public Assembly GetAssemblyFromFile(string fullFilePath)
		{
			Assembly assembly = Assembly.LoadFrom(fullFilePath);

			return assembly;
		}

		public IEnumerable<Attribute> GetCustomAttributes(MethodInfo method)
		{
			return method.GetCustomAttributes();
		}

		public IEnumerable<Attribute> GetCustomAttributes(Type type)
		{
			return type.GetCustomAttributes();
		}

		public string GetMethodName(MethodInfo method)
		{
			return method.Name;
		}

		public string GetMethodReflectedTypeFullName(MethodInfo method)
		{
			return method.ReflectedType.FullName;
		}

		public MethodInfo[] GetMethods(Type type)
		{
			return type.GetMethods();
		}

		public string GetTypeFullName(Type type)
		{
			return type.FullName;
		}

		public Type[] GetTypes(Assembly assembly)
		{
			return assembly.GetTypes();
		}
	}
}