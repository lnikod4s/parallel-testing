﻿using System.IO;
using System.Reflection;
using DistributedNUnit.Interfaces;

namespace DistributedNUnit.Infrastructure
{
    public class PathProvider : IPathProvider
    {
        public string GetFileName(string file)
        {
            return Path.GetFileName(file);
        }

        public string Combine(string path1, string path2)
        {
            return Path.Combine(path1, path2);
        }

        public string Combine(string path1, string path2, string path3)
        {
            return Path.Combine(path1, path2, path3);
        }
        
        public string GetTempFileName()
        {
            return Path.GetTempFileName();
        }
        
        public string GetTempFolderPath()
        {
			return Path.GetTempPath();
        }

		public string GetDirectoryName(string fullPath)
		{
			return Path.GetDirectoryName(fullPath);
		}

		public string GetExecutingAssemblyDirectory()
		{
			return Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
		}
	}
}