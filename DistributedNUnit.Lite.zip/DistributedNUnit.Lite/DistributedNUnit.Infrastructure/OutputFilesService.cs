﻿using System;
using System.IO;
using System.Linq;
using DistributedNUnit.Interfaces;

namespace DistributedNUnit.Infrastructure
{
    public class OutputFilesService : IOutputFilesService
	{
		private const string TestRunIdNullEmptyExceptionMessage = @"The test run ID cannot be empty or null.";
		private const string SharedOutputFilesEmptyNullExceptionMessage = @"The shared output files location cannot be empty or null.";
		private const string OriginalOutputFilesEmptyNullExceptionMessage = @"The original output files location cannot be empty or null.";
		private const string SharedOutputFilesLocationNotExistExceptionMessage = @"The shared output files location does not exist.";
		private const string WorkingDirectoryNotExistExceptionMessage = @"The working directory does not exist.";
		private const string OriginalOutputFilesLocationNotExistExceptionMessage = @"The original output files location does not exist.";
		private const string TestListNullExceptionMessage = @"The test list cannot be empty or null.";
		private readonly IFileProvider fileProvider;
		private readonly IDirectoryProvider directoryProvider;
		private readonly IPathProvider pathProvider;

		public OutputFilesService(IFileProvider fileProvider, IDirectoryProvider directoryProvider, IPathProvider pathProvider)
		{
			this.fileProvider = fileProvider;
			this.directoryProvider = directoryProvider;
			this.pathProvider = pathProvider;
		}

		public string CreateLocalTestListFile(string testList)
		{
			if (string.IsNullOrEmpty(testList))
			{
				throw new ArgumentNullException(TestListNullExceptionMessage);
			}
			string testListContent = testList;
			string testListFilePath = this.pathProvider.GetTempFileName();
			this.fileProvider.WriteAllText(testListFilePath, testListContent);

			return testListFilePath;
		}

		public void CopyOutputFilesToSharedLocation(Guid testRunId, string sharedOutputFilesLocation, string originalOutputFilesLocation)
		{
			this.ValidateCopyOutputFilesToSharedLocationsParameters(testRunId, sharedOutputFilesLocation, originalOutputFilesLocation);
			string newTestRunDirectoryPath = this.BuildTestRunIdFolderPath(testRunId, sharedOutputFilesLocation);
			this.AssureTestRunIdFolderCreated(newTestRunDirectoryPath);
			this.CopyOutputFilesToNewTestRunFolder(newTestRunDirectoryPath, originalOutputFilesLocation);
		}

		public void CopyResultsOutputFilesToResultsOutputLocation(string workingDirectory, string resultsOutputLocation, params string[] excludeDirs)
		{
			if (resultsOutputLocation != null)
			{
				if (!this.directoryProvider.DoesDirectoryExists(workingDirectory))
				{
					throw new ArgumentNullException(WorkingDirectoryNotExistExceptionMessage);
				}
				this.CopyAll(workingDirectory, resultsOutputLocation, excludeDirs);
			}
		}

		private void ValidateCopyOutputFilesToSharedLocationsParameters(Guid testRunId, string sharedOutputFilesLocation, string originalOutputFilesLocation)
		{
			if (testRunId.Equals(Guid.Empty))
			{
				throw new ArgumentNullException(TestRunIdNullEmptyExceptionMessage);
			}
			if (string.IsNullOrEmpty(sharedOutputFilesLocation))
			{
				throw new ArgumentNullException(SharedOutputFilesEmptyNullExceptionMessage);
			}
			if (string.IsNullOrEmpty(originalOutputFilesLocation))
			{
				throw new ArgumentNullException(OriginalOutputFilesEmptyNullExceptionMessage);
			}
			if (!this.directoryProvider.DoesDirectoryExists(sharedOutputFilesLocation))
			{
				throw new ArgumentNullException(SharedOutputFilesLocationNotExistExceptionMessage);
			}
			if (!this.directoryProvider.DoesDirectoryExists(originalOutputFilesLocation))
			{
				throw new ArgumentNullException(OriginalOutputFilesLocationNotExistExceptionMessage);
			}
		}

		private string BuildTestRunIdFolderPath(Guid testRunId, string sharedOutputFilesLocation)
		{
			string newTestRunDirectoryPath = this.pathProvider.Combine(sharedOutputFilesLocation, testRunId.ToString());
			return newTestRunDirectoryPath;
		}

		private void AssureTestRunIdFolderCreated(string newTestRunDirectoryPath)
		{
			if (!this.directoryProvider.DoesDirectoryExists(newTestRunDirectoryPath))
			{
				this.directoryProvider.CreateDirectory(newTestRunDirectoryPath);
			}
		}

		private void CopyOutputFilesToNewTestRunFolder(string newTestRunDirectoryPath, string originalOutputFilesLocation, params string[] excludeDirs)
		{
			this.CopyAll(originalOutputFilesLocation, newTestRunDirectoryPath, excludeDirs);
		}

		private void CopyAll(string sourceDirectory, string targetDirectory, params string[] excludeDirs)
		{
			if (!string.IsNullOrEmpty(sourceDirectory) && !string.IsNullOrEmpty(targetDirectory))
			{
				DirectoryInfo dirInfoSource = new DirectoryInfo(sourceDirectory);
				DirectoryInfo dirInfoTarget = new DirectoryInfo(targetDirectory);

				this.CopyAll(dirInfoSource, dirInfoTarget, excludeDirs);
			}
		}

		private void CopyAll(DirectoryInfo source, DirectoryInfo target, params string[] excludeDirs)
		{
			Directory.CreateDirectory(target.FullName);

			// Copy each file into the new directory.
			foreach (FileInfo fileInfo in source.GetFiles())
			{
				fileInfo.CopyTo(Path.Combine(target.FullName, fileInfo.Name), true);
			}

			// Copy each subdirectory using recursion.
			foreach (DirectoryInfo dirInfoSourceSubDir in source.GetDirectories())
			{
				if (!excludeDirs.Contains(dirInfoSourceSubDir.Name))
				{
					DirectoryInfo nextTargetSubDir =
						target.CreateSubdirectory(dirInfoSourceSubDir.Name);
					this.CopyAll(dirInfoSourceSubDir, nextTargetSubDir);
				}
			}
		}
	}
}