﻿using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Threading;
using DistributedNUnit.Interfaces;
using Microsoft.Win32.SafeHandles;

namespace DistributedNUnit.Infrastructure
{
	/// <summary>Starts a process and allows capturing the output (both standard and error).</summary>
	public class ProcessProvider : IProcessProvider
	{
		/// <summary>Starts a new process with the specified file name and arguments.</summary>
		/// <param name="fileName">The name of the file to start.</param>
		/// <param name="workingDir">The working directory.</param>
		/// <param name="arguments">The arguments to pass to the started application.</param>
		/// <param name="timeoutMinutes">The time that the program will wait for the process to finish in minutes.</param>
		/// <param name="standardOutputCallback">A callback function that is called when data is written to the standard output.</param>
		/// <param name="errorOutputCallback">A callback function that is called when data is written to the error output.</param>
		/// <returns>The exit code of the process.</returns>
		/// <remarks>Both standardOutputCallback and errorOutputCallback can be null. In that case, the specified data is not captured.
		/// The single argument to both these callback functions is the data that was written to the specified output.</remarks>
		public int StartProcess(
			string fileName,
			string workingDir,
			string arguments,
			CancellationToken cancellationToken,
			Action<string> standardOutputCallback = null,
			Action<string> errorOutputCallback = null)
		{
			bool redirectStandard = standardOutputCallback != null;
			bool redirectError = errorOutputCallback != null;

			var startInfo = this.InitializeProcessStartInfo(fileName, workingDir, arguments, redirectStandard, redirectError);

			var process = this.InitializeProcess(standardOutputCallback, errorOutputCallback, redirectStandard, redirectError, startInfo);

			using (process)
			{
				process.Start();

				this.ExecutePostProcessStartActions(redirectStandard, redirectError, process);

				this.Wait(process, cancellationToken);

				return 0;
			}
		}

		public void StartParentlessProcess(string fileName, string arguments)
		{
			string cmdFile = "cmd.exe";
			string cmdArguments = $"/C start {fileName} {arguments}";
			var startInfo = new ProcessStartInfo(cmdFile, cmdArguments)
			{
				WindowStyle = ProcessWindowStyle.Hidden
			};
			Process.Start(startInfo);
		}

		public void StartProcess(string fileName, string arguments)
		{
			var startInfo = new ProcessStartInfo(fileName, arguments)
			{
				WindowStyle = ProcessWindowStyle.Hidden
			};
			var process = new Process
			{
				StartInfo = startInfo
			};

			using (process)
			{
				process.Start();
			}
		}

		public void KillProcess(int processId)
		{
			Process process = Process.GetProcessById(processId);
			process.Kill();
		}

		private ProcessStartInfo InitializeProcessStartInfo(string fileName, string workingDir, string arguments, bool redirectStandard, bool redirectError)
		{
			var startInfo = new ProcessStartInfo(fileName, arguments);
			//// UseShellExecute has to be false if standard or error output is redirected
			startInfo.UseShellExecute = false;
			startInfo.CreateNoWindow = true;
			if (!string.IsNullOrEmpty(workingDir))
			{
				startInfo.WorkingDirectory = workingDir;
			}
			if (redirectStandard || redirectError)
			{
				if (redirectStandard)
				{
					startInfo.RedirectStandardOutput = true;
				}

				if (redirectError)
				{
					startInfo.RedirectStandardError = true;
				}
			}
			return startInfo;
		}

		private Process InitializeProcess(
			Action<string> standardOutputCallback,
			Action<string> errorOutputCallback,
			bool redirectStandard,
			bool redirectError,
			ProcessStartInfo startInfo)
		{
			var process = new Process();
			process.EnableRaisingEvents = true;
			process.StartInfo = startInfo;
			if (redirectStandard || redirectError)
			{
				// the events are only raised if this property is set to true
				process.EnableRaisingEvents = true;

				if (redirectStandard)
				{
					process.OutputDataReceived += (_, e) => standardOutputCallback(e.Data);
				}

				if (redirectError)
				{
					process.ErrorDataReceived += (_, e) => errorOutputCallback(e.Data);
				}
			}

			return process;
		}

		private void ExecutePostProcessStartActions(bool redirectStandard, bool redirectError, Process process)
		{
			// capturing standard output only starts if you call BeginOutputReadLine
			if (redirectStandard)
			{
				process.BeginOutputReadLine();
			}

			// capturing error output only starts if you call BeginErrorReadLine
			if (redirectError)
			{
				process.BeginErrorReadLine();
			}
		}

		private void Wait(Process process, CancellationToken token)
		{
			using (var waitHandle = new SafeWaitHandle(process.Handle, false))
			{
				using (var processFinishedEvent = new ManualResetEvent(false))
				{
					processFinishedEvent.SafeWaitHandle = waitHandle;

					int index = WaitHandle.WaitAny(new[] { processFinishedEvent, token.WaitHandle });
					if (index == 1)
					{
						this.KillProcessChromeDriverChild(process);
						Thread.Sleep(5000);
						process.Kill();
					}
				}
			}
		}

		private void KillProcessChromeDriverChild(Process process)
		{
			string path = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "DistributedNUnit.RunawayProcessKiller.exe");
			this.StartProcess(path, process.Id.ToString());
		}
	}
}