1. Copy the content of DistributedNUnit.TestAgent.Setup folder to a local folder on the agent machine and remove the read-only flag.
2. Update the default test agent name in StartAgents.bat and UpdateAndRestartAgents.bat, the default is myTestAgent and the default count is 12 instances. 
Use unique and meaningful name. For service tests, you can use 2 x CPU cores as instances and for UI tests it's best optimal to use CPU cores.
3. Run InstallAgent.bat
4. Run StartAgents.bat
5. If a new version is released or you want to reboot the rig, run UpdateAndRestartAgents.bat
6. Before tests execution make sure the server has installed latest version of NUnit console found here: https://github.com/nunit/nunit-console/releases/
7. To use the above-setuped agent pool you must install the NuGet package "DistributedNUnit.TestController" installed on your project for the tests.
8. After installing the "DistributedNUnit.TestController" test package you can execute the tests via the following command:
dotnet {YourTestProject\bin\BuildConfiguration}\NunitTestController\DistributedNUnit.TestController.dll

Parameters are as follows:

Usage: [options]

Options:
  -$|-r |--resultsFolder <.workspase/results/>                      The local folder in which the test results will be saved.
  -$|-t |--testAssembly <.workspase/bin/release/unit.tests.dll>     The test assembly path to execute tests from.
  -$|-c |--testCategories <SmokeTests_Category1>                    The test categories from which the tests will run. Separated by _
  -$|-s |--sharedOutputFilesLocation <//fileserver/testrun/>        The shared folder from which the agents will run the tests.
  -$|-f |--resultsOutputFolder <//fileserver/testrun/outputFiles/>  The shared folder in which the tests can save stuff during execution.
  -$|-a |--agentTagName <UnitTestsAgent1>                           The tag for the test agent to run the tests on
  -$|-x |--testAgentsCount <5>                                      Specify how many test agents to distribute to. The default is the maximum subscribed to the tag.
  -$|-e |--testRunTimeout <180>                                     Specify how many minutes to wait wintil the run is aborted.
  -? | -h | --help                                                  Show help information

  Here is an example that can be used in https://jenkins.bizservices.progress.com jobs:

  %DOTNET% %WORKSPACE%\Admin.SystemTests\bin\%BuildConfiguration%\%NUNIT_RUNNER% 
  -r %WORKSPACE%\Admin.SystemTests\TestResults\ 
  -t %WORKSPACE%\Admin.SystemTests\bin\%BuildConfiguration%\Admin.SystemTests.dll 
  -c %TestCategory% 
  -s \\FILESRVBG01\Distributions\DailyBuilds\BusinessServices\SystemTests\NunitTestRuns\ 
  -f \\FILESRVBG01\Distributions\DailyBuilds\BusinessServices\SystemTests\TestTraceData\SIT\%JOB_NAME%-%BUILD_NUMBER%\ 
  -a webUIApplicationTests 
  -e 280 
  -x %AgentsCount%

  ** BuildConfiguration, TestCategory, AgentsCount - are job local defined string params

 * testCategories (-t) is optional, if not provided all tests from the assembly will be executed
 * resultsOutputFolder (-f) is optional, this is the location any screenshots of failed tests may be saved
 * testAgentsCount (-x) is optional, the default value is 1
 * testRunTimeout (-e) is optional, the default value is 60 (mins)