﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using DistributedNUnit.Infrastructure;
using DistributedNUnit.Logger;
using DistributedNUnit.Model;
using DistributedNUnit.Model.Constants;
using DistributedNUnit.Services;
using Newtonsoft.Json;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;

namespace DistributedNUnit.RabbitMq.Client.Incoming
{
    public class Consumer
    {
        private const string TestNameRegex = @"=> (?<TestName>.+)";

        // This is executed in the test agent.
        public void ProcessTestRunMessages(string testAgentTag)
        {
            var factory = new ConnectionFactory()
            {
                HostName = Factory.HostName,
                UserName = Factory.UserName,
                Password = Factory.Password,
                VirtualHost = Factory.VirtualHost,
                Port = Factory.Port
            };

            string queueName = $"{Queues.TestsRun}.{testAgentTag}";

            using (var connection = factory.CreateConnection())
            using (var channel = connection.CreateModel())
            {
                channel.ExchangeDeclare(exchange: Exchanges.NewTestRun, type: "direct", durable: true);

                channel.QueueDeclare(queue: queueName,
                                     durable: true,
                                     exclusive: false,
                                     autoDelete: false,
                                     arguments: null);

                channel.BasicQos(prefetchSize: 0, prefetchCount: 1, global: false);

                channel.QueueBind(queue: queueName,
                                  exchange: Exchanges.NewTestRun,
                                  routingKey: testAgentTag);

                Console.WriteLine($" [*] Agent start success. Name: {testAgentTag} - Version: {Assembly.GetExecutingAssembly().GetName().Version.ToString()}");

                var consumer = new EventingBasicConsumer(channel);
                consumer.Received += (model, ea) =>
                {
                    var body = ea.Body.ToArray();
                    var message = Encoding.UTF8.GetString(body);
                    var testRun = JsonConvert.DeserializeObject<TestRun>(message);

                    // Here execute the provided tests in the test run. This method should continue after all tests are finished.
                    var testAgentExecutionService = new TestAgentExecutionService(
                        new NUnitRunner(
                            new ProcessProvider(),
                            new FileProvider(),
                            new PathProvider(),
                            new ConsoleProvider()),
                        new OutputFilesService(
                            new FileProvider(),
                            new DirectoryProvider(),
                            new PathProvider()),
                        new PathProvider(),
                        new DirectoryProvider(),
                        new ConsoleProvider());

                    var tokenSource = new CancellationTokenSource(TimeSpan.FromMinutes(testRun.Timeout));

                    try
                    {
                        Task.Run(() => this.ProcessTestRunCancelationMessages(testAgentTag, testRun.TestRunId, tokenSource), tokenSource.Token);
                        Thread.Sleep(2000); // wait for the cancelation listener to start fully.
                        testAgentExecutionService.Execute(testRun, tokenSource.Token);
                        if (!tokenSource.IsCancellationRequested)
                        {
                            Console.WriteLine(" => Canceling the execution after the execution has completed.");
                            tokenSource.Cancel();
                        }

                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($" => [x] Test execution has encoutered unexpected error: {testRun.TestRunId}. Error: {ex.ToString()}");
                        if (!tokenSource.IsCancellationRequested)
                        {
                            tokenSource.Cancel();
                        }
                    }

                    Console.WriteLine($" [x] Finished running tests for test run: {testRun.TestRunId}");

                    if (tokenSource != null)
                    {
                        try
                        {
                            tokenSource.Dispose();
                        }
                        catch
                        {
                        }
                    }
                    
                    channel.BasicAck(deliveryTag: ea.DeliveryTag, multiple: false);
                };

                channel.BasicConsume(queue: queueName,
                                     autoAck: false,
                                     consumer: consumer);

                Console.ReadLine();
            }
        }

        // This is executed in the test agent after starting each test run and upon finish is cancelled.
        public void ProcessTestRunCancelationMessages(string tagName, Guid testRunId, CancellationTokenSource cancellationTokenSource)
        {
            var factory = new ConnectionFactory()
            {
                HostName = Factory.HostName,
                UserName = Factory.UserName,
                Password = Factory.Password,
                VirtualHost = Factory.VirtualHost,
                Port = Factory.Port
            };

            string queueName = $"{Queues.TestRunCancelation}.{tagName}.{Guid.NewGuid().ToString()}";
            string exchangeName = $"{Exchanges.CancelationTestRun}.{testRunId}";

            using (var connection = factory.CreateConnection())
            using (var channel = connection.CreateModel())
            {
                var args = new Dictionary<string, object>
                        {
                            { "x-expires", (int)TimeSpan.FromSeconds(10).TotalMilliseconds }
                        };

                channel.ExchangeDeclare(exchange: exchangeName,
                                        type: "fanout",
                                        durable: true,
                                        autoDelete: true,
                                        arguments: args);

                channel.QueueDeclare(queue: queueName,
                                     durable: true,
                                     exclusive: false,
                                     autoDelete: true,
                                     arguments: args);

                channel.BasicQos(prefetchSize: 0, prefetchCount: 1, global: false);

                channel.QueueBind(queue: queueName,
                                  exchange: exchangeName,
                                  routingKey: testRunId.ToString());

                var consumer = new EventingBasicConsumer(channel);
                consumer.Received += (model, ea) =>
                {
                    // Abort message is received so send abort command to the test runner.
                    cancellationTokenSource.Cancel();
                    Console.WriteLine($" => [x] Test run execution has been aborted by the controller: {testRunId}");
                };

                channel.BasicConsume(queue: queueName,
                                     autoAck: true,
                                     consumer: consumer);

                Task.WaitAll(Task.Run(() =>
                {
                    while (!cancellationTokenSource.Token.IsCancellationRequested)
                    {
                        Thread.Sleep(1000);
                    }
                }));
            }
        }

        // This is executed in the test controller
        public void ProcessTestRunLogMessages(string tagName, Guid testRunId, List<string> allTests, CancellationToken cancellationToken)
        {
            var factory = new ConnectionFactory()
            {
                HostName = Factory.HostName,
                UserName = Factory.UserName,
                Password = Factory.Password,
                VirtualHost = Factory.VirtualHost,
                Port = Factory.Port
            };

            string queueName = $"{Queues.TestsRunConsoleOutput}.{tagName}.{testRunId}";

            using (var connection = factory.CreateConnection())
            using (var channel = connection.CreateModel())
            {
                channel.ExchangeDeclare(exchange: Exchanges.ConsoleOutput, type: "direct", durable: true);
                var args = new Dictionary<string, object>
                        {
                            { "x-expires", (int)TimeSpan.FromHours(1).TotalMilliseconds }
                        };

                channel.QueueDeclare(queue: queueName,
                                     durable: true,
                                     exclusive: false,
                                     autoDelete: true,
                                     arguments: args);

                channel.QueueBind(queue: queueName,
                                  exchange: Exchanges.ConsoleOutput,
                                  routingKey: testRunId.ToString());

                var consumer = new EventingBasicConsumer(channel);
                consumer.Received += (model, ea) =>
                {
                    var body = ea.Body.ToArray();
                    var message = Encoding.UTF8.GetString(body);
                    var testRunLog = JsonConvert.DeserializeObject<TestRunConsoleOutput>(message);
                    if (testRunLog.ConsoleMessage.Length > 0)
                    {
                        string consoleMessage = testRunLog.ConsoleMessage;
                        Match m = Regex.Match(testRunLog.ConsoleMessage, TestNameRegex, RegexOptions.Singleline | RegexOptions.IgnoreCase);

                        if (m.Success && (consoleMessage.Contains("Passed") || consoleMessage.Contains("Error") || consoleMessage.Contains("Fail")))
                        {
                            string testName = m.Groups["TestName"].Value;
                            allTests.Remove(testName);
                            consoleMessage += $" => {allTests.Count} tests remaining.";
                        }

                        Console.WriteLine(consoleMessage);
                    }
                };

                channel.BasicConsume(queue: queueName,
                                     autoAck: true,
                                     consumer: consumer);

                Task.WaitAll(Task.Run(() =>
                {
                    while (!cancellationToken.IsCancellationRequested)
                    {
                        Thread.Sleep(200);
                    }
                }));
            }
        }

        // This is executed in the test controller
        public Success ProcessTestRunResultMessages(string tagName, Guid testRunId, uint resultsCount, string testResultsFolder, int testRunTimeout, Dictionary<Guid, decimal> estimatedTimes)
        {
            uint processedResultsCount = 0;
            Success success = new Success
            {
                Timeout = true,
                TestResult = true
            };

            var factory = new ConnectionFactory()
            {
                HostName = Factory.HostName,
                UserName = Factory.UserName,
                Password = Factory.Password,
                VirtualHost = Factory.VirtualHost,
                Port = Factory.Port
            };

            string queueName = $"{Queues.TestsRunTestsResults}.{tagName}.{testRunId}";

            using (var connection = factory.CreateConnection())
            using (var channel = connection.CreateModel())
            {
                channel.ExchangeDeclare(exchange: Exchanges.TestRunResult, type: "direct", durable: true);

                var args = new Dictionary<string, object>
                        {
                            { "x-expires", (int)TimeSpan.FromSeconds(60).TotalMilliseconds }
                        };

                channel.QueueDeclare(queue: queueName,
                                     durable: true,
                                     exclusive: false,
                                     autoDelete: true,
                                     arguments: args);

                channel.QueueBind(queue: queueName,
                                  exchange: Exchanges.TestRunResult,
                                  routingKey: testRunId.ToString());

                var consumer = new EventingBasicConsumer(channel);
                var tokenSource = new CancellationTokenSource();

                consumer.Received += (model, ea) =>
                {
                    var body = ea.Body.ToArray();
                    var message = Encoding.UTF8.GetString(body);
                    var testRunResult = JsonConvert.DeserializeObject<TestRunResult>(message);
                    if (testRunResult.Status == "Started")
                    {
                        tokenSource.CancelAfter(TimeSpan.FromMinutes(testRunTimeout));
                        ConsoleLogger.Log($" [x] Received Test Run Started message for ID: {testRunResult.TestRunId}");
                    }
                    else
                    {
                        ConsoleLogger.Log($" [x] Received results for Test Run ID : {testRunResult.TestRunId} - {testRunResult.Status} - estimated time: {estimatedTimes[testRunResult.ResultId]}, actual time: {testRunResult.TimeTaken}");
                        processedResultsCount++;

                        var testResultsService = new TestResultsService(
                            new FileProvider(),
                            new DirectoryProvider(),
                            new PathProvider());

                        if (testRunResult.Status == "Success")
                        {
                            testResultsService.SaveTestResults(testRunResult.TestResults, testResultsFolder, (int)resultsCount);
                        }
                        else
                        {
                            success.Timeout = false;
                            ConsoleLogger.LogError($" [x] Received non success result from test agent. Test agent timed out after {testRunTimeout} minutes.{Environment.NewLine}Status : {testRunResult.Status}");
                        }

                        if (!testRunResult.IsTestsResultSuccess)
                        {
                            success.TestResult = false;
                        }
                    }
                };

                channel.BasicConsume(queue: queueName,
                                     autoAck: true,
                                     consumer: consumer);

                Task.Run(() =>
                {
                    while (resultsCount != processedResultsCount)
                    {
                        Thread.Sleep(500);
                        if (tokenSource.Token.IsCancellationRequested)
                        {
                            success.Timeout = false;
                            ConsoleLogger.LogError($" [x] Test controller task cancelation received. Test controller timed out after {testRunTimeout} minutes.");
                            break;
                        }
                    }
                    foreach (var tag in consumer.ConsumerTags)
                    {
                        if (channel != null)
                        {
                            channel.BasicCancel(tag);
                        }
                    }
                }, tokenSource.Token).Wait();
            }
            return success;
        }

        // This is used in the test controller to determine the maximum agents connected
        public uint GetConsumers(string queueName, bool declareIfNotExists = false, int retryCount = 5)
        {
            uint consumerCount = 0;

            while (retryCount-- > 0)
            {
                try
                {
                    var factory = new ConnectionFactory()
                    {
                        HostName = Factory.HostName,
                        UserName = Factory.UserName,
                        Password = Factory.Password,
                        VirtualHost = Factory.VirtualHost,
                        Port = Factory.Port
                    };

                    using (var connection = factory.CreateConnection())
                    using (var channel = connection.CreateModel())
                    {
                        var queueDeclareOK = channel.QueueDeclarePassive(queueName);
                        consumerCount = queueDeclareOK.ConsumerCount;
                    }
                    break;
                }
                catch (Exception)
                {
                    if (declareIfNotExists)
                    {
                        this.DeclareAndBindTestRunQueue(queueName);
                    }
                    Thread.Sleep(2000);
                    continue;
                }
            }

            return consumerCount;
        }

        public uint GetConsumers(string queueName)
        {
            uint consumerCount = 0;

            try
            {
                var factory = new ConnectionFactory()
                {
                    HostName = Factory.HostName,
                    UserName = Factory.UserName,
                    Password = Factory.Password,
                    VirtualHost = Factory.VirtualHost,
                    Port = Factory.Port
                };

                using (var connection = factory.CreateConnection())
                using (var channel = connection.CreateModel())
                {
                    var queueDeclareOK = channel.QueueDeclarePassive(queueName);
                    consumerCount = queueDeclareOK.ConsumerCount;
                }
            }
            catch (Exception)
            {
                return 0;
            }

            return consumerCount;
        }

        // This is executed in the upgrade service listener to process commands for upgrading the version.
        public void ProcessAgentVersionUpgradeMessages(string machineName)
        {
            var factory = new ConnectionFactory()
            {
                HostName = Factory.HostName,
                UserName = Factory.UserName,
                Password = Factory.Password,
                VirtualHost = Factory.VirtualHost,
                Port = Factory.Port
            };

            string queueName = $"{Queues.AgentVersionUpgradeQueue}.{machineName}";

            using (var connection = factory.CreateConnection())
            using (var channel = connection.CreateModel())
            {
                channel.ExchangeDeclare(exchange: Exchanges.AgentVersionUpgrade, type: "direct", durable: true);

                channel.QueueDeclare(queue: queueName,
                                     durable: true,
                                     exclusive: false,
                                     autoDelete: false,
                                     arguments: null);

                channel.BasicQos(prefetchSize: 0, prefetchCount: 10, global: false);

                channel.QueueBind(queue: queueName,
                                  exchange: Exchanges.AgentVersionUpgrade,
                                  routingKey: machineName);

                Console.WriteLine("[*] Upgrade service started. Listening for new versions...");

                var consumer = new EventingBasicConsumer(channel);
                consumer.Received += (model, ea) =>
                {
                    var body = ea.Body.ToArray();
                    var message = Encoding.UTF8.GetString(body);
                    var upgrade = JsonConvert.DeserializeObject<UpgradeMessage>(message);

                    new ProcessProvider().StartProcess("cmd.exe", $"/C start {upgrade.AgentPath}\\UpdateAndRestartAgents.bat");
                    channel.Dispose();
                    connection.Dispose();

                    Environment.Exit(0);
                };

                channel.BasicConsume(queue: queueName,
                                     autoAck: true,
                                     consumer: consumer);

                Console.ReadLine();
            }
        }

        public void RemoveUnprocessedMessagesForTestRun(Guid testRunId, string queueName)
        {
            var factory = new ConnectionFactory()
            {
                HostName = Factory.HostName,
                UserName = Factory.UserName,
                Password = Factory.Password,
                VirtualHost = Factory.VirtualHost,
                Port = Factory.Port
            };

            using (var connection = factory.CreateConnection())
            using (var channel = connection.CreateModel())
            {
                ulong? lastDeliveryTag = default;

                BasicGetResult currentMessage;

                while ((currentMessage = channel.BasicGet(queueName, false)) != null)
                {
                    lastDeliveryTag = currentMessage.DeliveryTag;
                    TestRun resultObject = JsonConvert.DeserializeObject<TestRun>(Encoding.UTF8.GetString(currentMessage.Body.ToArray()));
                    if (resultObject.TestRunId == testRunId)
                    {
                        channel.BasicNack(lastDeliveryTag.Value, false, false);
                    }
                    else
                    {
                        channel.BasicNack(lastDeliveryTag.Value, false, true);
                    }
                }
            }
        }

        private void DeclareAndBindTestRunQueue(string queueName)
        {
            try
            {
                var factory = new ConnectionFactory()
                {
                    HostName = Factory.HostName,
                    UserName = Factory.UserName,
                    Password = Factory.Password,
                    VirtualHost = Factory.VirtualHost,
                    Port = Factory.Port
                };

                using (var connection = factory.CreateConnection())
                using (var channel = connection.CreateModel())
                {
                    channel.ExchangeDeclare(exchange: Exchanges.NewTestRun, type: "direct", durable: true);

                    channel.QueueDeclare(queue: queueName,
                                         durable: true,
                                         exclusive: false,
                                         autoDelete: false,
                                         arguments: null);

                    channel.BasicQos(prefetchSize: 0, prefetchCount: 1, global: false);

                    channel.QueueBind(queue: queueName,
                                      exchange: Exchanges.NewTestRun,
                                      routingKey: queueName.Split('.')[2]);
                }
            }
            catch (Exception)
            {
            }
        }
    }
}