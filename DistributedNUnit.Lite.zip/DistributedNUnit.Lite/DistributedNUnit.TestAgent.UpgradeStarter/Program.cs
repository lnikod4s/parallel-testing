﻿using DistributedNUnit.RabbitMq.Client.Outgoing;

namespace DistributedNUnit.TestAgent.UpgradeStarter
{
	class Program
    {
        static void Main(string[] args)
        {
			string agentPath = args[0];

			for (int i = 0; i < args.Length; i++)
			{
				if (i > 0)
				{
					new Producer().SendTestAgentVersionUpgradeMessage(new Model.UpgradeMessage { AgentPath = agentPath }, args[i]);
				}
			}
		}
    }
}